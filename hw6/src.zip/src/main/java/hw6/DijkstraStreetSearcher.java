package hw6;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class DijkstraStreetSearcher extends StreetSearcher {

  private Map<Vertex<String>,Double> distances;

  /**
   * Creates a StreetSearcher object.
   *
   * @param graph an implementation of Graph ADT.
   */
  public DijkstraStreetSearcher(Graph<String, String> graph) {
    super(graph);
  }

  @Override
  public void findShortestPath(String startName, String endName) {
    Vertex<String> start = vertices.get(startName);
    Vertex<String> end = vertices.get(endName);

    if (handleErrorCases(startName, endName, start, end)) {
      return;
    }

    double totalDist;  // totalDist must be update below

    initialize(start);
    dijkstraAlgorithm(start,end);

    Double dijkstraDistance = distances.get(end);
    if (dijkstraDistance.isInfinite()) {
      totalDist = -1;
    } else {
      totalDist = dijkstraDistance;
    }


    // These method calls will create and print the path for you
    List<Edge<String>> path = getPath(end, start);
    if (VERBOSE) {
      printPath(path, totalDist);
    }
  }

  // helper for printing and when there are errors
  private boolean handleErrorCases(
          String startName,
          String endName,
          Vertex<String> start,
          Vertex<String> end) {
    if (start == null || end == null) {
      String badVertex = (start == null ? startName : endName);
      System.out.println("Invalid Endpoint: " + badVertex);
      return true;
    }
    if (start.equals(end)) {
      System.out.println("No path found");
      return true;
    }
    return false;
  }

  //helper function to initialize all the elements
  private void initialize(Vertex<String> start) {
    //create map and initialize all to have positive infinity as distance
    distances = new HashMap<Vertex<String>,Double>();
    for (Vertex<String> vertex : graph.vertices()) {
      distances.put(vertex, Double.POSITIVE_INFINITY);
    }
    distances.put(start, 0.0); //initialize the start as 0
  }

  //helper function that implements Dijkstra's Algorithm
  private void dijkstraAlgorithm(Vertex<String> start, Vertex<String> end) {

    //create a min heap to allow for faster algorithm
    PriorityQueue<Node> pq = new PriorityQueue<>();
    pq.add(new Node(start,0.0));

    while (!pq.isEmpty()) {
      //get the smallest element and its distance
      Node node = pq.poll();
      Vertex<String> vertex = node.vertex;
      double dist = node.distance;

      //check if we already have a better entry
      if (dist > distances.get(vertex)) {
        continue;
      }
      //we have reached the end
      if (vertex.equals(end)) {
        break;
      }
      //update the TODO
      updateDistances(vertex, dist, pq);
    }
  }

  //helper function to update the distances map
  private void updateDistances(Vertex<String> vertex, double dist, PriorityQueue<Node> pq) {

    //for all edges from the vertex
    for (Edge<String> edge : graph.outgoing(vertex)) {
      Vertex<String> u = graph.to(edge);

      //check the distance for edge by getting label
      double w = ((Number)graph.label(edge)).doubleValue();
      double alternative = dist + w;

      //add the better node to distances if needed
      if (alternative < distances.get(u)) {
        distances.put(u, alternative);
        graph.label(u,edge);
        pq.add(new Node(u,alternative));
      }
    }
  }


  //Node class to help with the priority queue
  private static class Node implements Comparable<Node> {
    private Vertex<String> vertex;
    private double distance;

    Node(Vertex<String> vertex, double distance) {
      this.vertex = vertex;
      this.distance = distance;
    }

    @Override
    public int compareTo(Node o) {
      return Double.compare(distance,o.distance);
    }

  }

}