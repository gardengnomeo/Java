package hw6;

import exceptions.InsertionException;
import exceptions.PositionException;
import exceptions.RemovalException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * An implementation of Graph ADT using incidence lists
 * for sparse graphs where most nodes aren't connected.
 *
 * @param <V> Vertex element type.
 * @param <E> Edge element type.
 */
public class SparseGraph<V, E> implements Graph<V, E> {

  private List<VertexNode<V>> vertices;
  private List<EdgeNode<E>> edges;

  /**
   * Constructor for sparse graph.
   */
  public SparseGraph() {
    vertices = new ArrayList<VertexNode<V>>();
    edges = new ArrayList<EdgeNode<E>>();
  }

  // Converts the vertex back to a VertexNode to use internally
  private VertexNode<V> convert(Vertex<V> v) throws PositionException {
    try {
      VertexNode<V> gv = (VertexNode<V>) v;
      if (gv.owner != this) {
        throw new PositionException();
      }
      return gv;
    } catch (NullPointerException | ClassCastException ex) {
      throw new PositionException();
    }
  }

  // Converts and edge back to a EdgeNode to use internally
  private EdgeNode<E> convert(Edge<E> e) throws PositionException {
    try {
      EdgeNode<E> ge = (EdgeNode<E>) e;
      if (ge.owner != this) {
        throw new PositionException();
      }
      return ge;
    } catch (NullPointerException | ClassCastException ex) {
      throw new PositionException();
    }
  }

  @Override
  public Vertex<V> insert(V v) throws InsertionException {
    //check for exceptions
    if (v == null) {
      throw new InsertionException();
    }
    for (VertexNode<V> vertex : vertices) {
      if (vertex.data == v) {
        throw new InsertionException();
      }
    }

    //add the vertex to the graph
    VertexNode<V> newVertex = new VertexNode<>(v);
    vertices.add(newVertex);
    return newVertex;
  }

  @Override
  public Edge<E> insert(Vertex<V> from, Vertex<V> to, E e)
      throws PositionException, InsertionException {

    //convert vertex to vertex nodes using helper function that checks exceptions
    VertexNode<V> fromNode = checkVertex(from);
    VertexNode<V> toNode = checkVertex(to);

    if (fromNode.equals(toNode)) {
      throw new InsertionException("self loops not allowed");
    }

    //check for duplicate
    for (EdgeNode<E> edge : fromNode.outgoing) {
      if (edge.to.equals(toNode)) {
        throw new InsertionException("duplicate edge not allowed");
      }
    }

    //insert edge and update information in vertices
    EdgeNode<E> newEdge = new EdgeNode<>(fromNode, toNode, e);

    fromNode.outgoing.add(newEdge);
    toNode.incoming.add(newEdge);

    edges.add(newEdge);
    return newEdge;
  }

  private VertexNode<V> checkVertex(Vertex<V> v) throws PositionException {
    if (v == null) {
      throw new PositionException();
    }

    VertexNode<V> node = convert(v);
    if (!vertices.contains(node)) {
      throw new PositionException();
    }
    return node;
  }

  @Override
  public V remove(Vertex<V> v) throws PositionException, RemovalException {

    if (v == null) {
      throw new PositionException("vertex cannot be null");
    }

    VertexNode<V> vertexNode = convert(v);

    if (!vertices.contains(vertexNode)) {
      throw new PositionException("vertex not found in graph");
    }

    //ensure vertex does not have any incident edges
    if (!vertexNode.outgoing.isEmpty() || !vertexNode.incoming.isEmpty()) {
      throw new RemovalException("vertex still has incident edges so can not remove");
    }

    //remove vertex
    vertices.remove(vertexNode);
    return vertexNode.data;
  }

  @Override
  public E remove(Edge<E> e) throws PositionException {
    if (e == null) {
      throw new PositionException("edge cannot be null");
    }

    EdgeNode<E> edgeNode = convert(e);

    if (!edges.contains(edgeNode)) {
      throw new PositionException("edge not found in graph");
    }

    //remove the edge and update vertices
    edgeNode.from.outgoing.remove(edgeNode);
    edgeNode.to.incoming.remove(edgeNode);
    edges.remove(edgeNode);

    return edgeNode.data;
  }

  @Override
  public Iterable<Vertex<V>> vertices() {
    //return unmodifiable so not able to modify with iterator
    return Collections.unmodifiableList(vertices);
  }

  @Override
  public Iterable<Edge<E>> edges() {
    //return unmodifiable so not able to modify with iterator
    return Collections.unmodifiableList(edges);
  }

  @Override
  public Iterable<Edge<E>> outgoing(Vertex<V> v) throws PositionException {
    if (v == null) {
      throw new PositionException("vertex cannot be null");
    }

    //check vertex in graph
    VertexNode<V> node = convert(v);
    if (!vertices.contains(node)) {
      throw new PositionException("vertex not found in graph");
    }

    //return unmodifiable so not able to modify with iterator
    return Collections.unmodifiableList(node.outgoing);
  }

  @Override
  public Iterable<Edge<E>> incoming(Vertex<V> v) throws PositionException {
    if (v == null) {
      throw new PositionException("vertex cannot be null");
    }

    //check vertex in graph
    VertexNode<V> node = convert(v);
    if (!vertices.contains(node)) {
      throw new PositionException("vertex not found in graph");
    }

    //return unmodifiable so not able to modify with iterator
    return Collections.unmodifiableList(node.incoming);
  }

  @Override
  public Vertex<V> from(Edge<E> e) throws PositionException {
    //check for issues
    if (e == null) {
      throw new PositionException("edge cannot be null");
    }

    EdgeNode<E> edgeNode = convert(e);
    if (!edges.contains(edgeNode)) {
      throw new PositionException("edge not found in graph");
    }

    return edgeNode.from;
  }

  @Override
  public Vertex<V> to(Edge<E> e) throws PositionException {
    //check for issues
    if (e == null) {
      throw new PositionException("edge cannot be null");
    }

    EdgeNode<E> edgeNode = convert(e);
    if (!edges.contains(edgeNode)) {
      throw new PositionException("edge not found in graph");
    }

    return edgeNode.to;
  }

  @Override
  public void label(Vertex<V> v, Object l) throws PositionException {
    if (v == null) {
      throw new PositionException("vertex cannot be null");
    }

    //check vertex in graph
    VertexNode<V> node = convert(v);
    if (!vertices.contains(node)) {
      throw new PositionException("vertex not found in graph");
    }

    //write the label
    node.label = l;
  }

  @Override
  public void label(Edge<E> e, Object l) throws PositionException {
    if (e == null) {
      throw new PositionException("edge cannot be null");
    }

    //check edge in graph
    EdgeNode<E> node = convert(e);
    if (!edges.contains(node)) {
      throw new PositionException("edge not found in graph");
    }

    //write the label
    node.label = l;
  }

  @Override
  public Object label(Vertex<V> v) throws PositionException {
    if (v == null) {
      throw new PositionException("vertex cannot be null");
    }

    //check vertex in graph
    VertexNode<V> node = convert(v);
    if (!vertices.contains(node)) {
      throw new PositionException("vertex not found in graph");
    }

    //return the label
    return node.label;
  }

  @Override
  public Object label(Edge<E> e) throws PositionException {
    if (e == null) {
      throw new PositionException("edge cannot be null");
    }

    //check edge in graph
    EdgeNode<E> node = convert(e);
    if (!edges.contains(node)) {
      throw new PositionException("edge not found in graph");
    }

    //return the label
    return node.label;
  }

  @Override
  public void clearLabels() {
    //set labels on all vertices to null
    for (VertexNode<V> vertexNode : vertices) {
      vertexNode.label = null;
    }
    //set labels on all edges to null
    for (EdgeNode<E> edgeNode : edges) {
      edgeNode.label = null;
    }
  }

  @Override
  public String toString() {
    GraphPrinter<V, E> gp = new GraphPrinter<>(this);
    return gp.toString();
  }

  // Class for a vertex of type V
  private final class VertexNode<V> implements Vertex<V> {
    V data;
    Graph<V, E> owner;
    Object label;


    private List<EdgeNode<E>> outgoing;
    private List<EdgeNode<E>> incoming;

    VertexNode(V v) {
      this.data = v;
      this.label = null;
      this.outgoing = new ArrayList<EdgeNode<E>>();
      this.incoming = new ArrayList<EdgeNode<E>>();
      this.owner = (Graph<V,E>) SparseGraph.this;
    }

    @Override
    public V get() {
      return this.data;
    }
  }

  //Class for an edge of type E
  private final class EdgeNode<E> implements Edge<E> {
    E data;
    Graph<V, E> owner;
    VertexNode<V> from;
    VertexNode<V> to;
    Object label;


    // Constructor for a new edge
    EdgeNode(VertexNode<V> f, VertexNode<V> t, E e) {
      this.from = f;
      this.to = t;
      this.data = e;
      this.label = null;
      this.owner = (Graph<V,E>) SparseGraph.this;

    }

    @Override
    public E get() {
      return this.data;
    }
  }
}
