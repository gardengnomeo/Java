package hw6;

import exceptions.InsertionException;
import exceptions.PositionException;
import exceptions.RemovalException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public abstract class GraphTest {

  protected Graph<String, String> graph;

  @BeforeEach
  public void setupGraph() {
    this.graph = createGraph();
  }

  protected abstract Graph<String, String> createGraph();

  @Test
  @DisplayName("insert(v) returns a vertex with given data")
  public void canGetVertexAfterInsert() {
    Vertex<String> v1 = graph.insert("v1");
    assertEquals("v1", v1.get());
  }

  @Test
  @DisplayName("insert(U, V, e) returns an edge with given data")
  public void canGetEdgeAfterInsert() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    assertEquals("v1-v2", e1.get());
  }

  @Test
  @DisplayName("insert(null, V, e) throws exception")
  public void insertEdgeThrowsPositionExceptionWhenFirstVertexIsNull() {
    try {
      Vertex<String> v = graph.insert("v");
      graph.insert(null, v, "e");
      fail("The expected exception was not thrown");
    } catch (PositionException ex) {
      return;
    }
  }

  @Test
  @DisplayName("insert(V, null, e) throws exception")
  public void insertEdgeThrowsPositionExceptionWhenSecondVertexIsNull() {
    try {
      Vertex<String> v = graph.insert("v");
      graph.insert(v, null, "e");
      fail("The expected exception was not thrown");
    } catch (PositionException ex) {
      return;
    }
  }

  @Test
  @DisplayName("insert(V1, V2, null) works")
  public void insertEdgeWhenNull() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e1 = graph.insert(v1, v2, null);
    assertNull(e1.get());
  }

  @Test
  @DisplayName("self loop throws exception")
  public void insertEdgeThrowsInsertionExceptionWhenSelfLoop() {
    Vertex<String> v1 = graph.insert("v1");
    try {
      graph.insert(v1, v1, "e");
      fail("The expected exception was not thrown");
    } catch (InsertionException ex) {
      return;
    }
  }

  @Test
  @DisplayName("duplicate edge throws exception")
  public void insertEdgeThrowsInsertionExceptionWhenDuplicateEdge() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    graph.insert(v1, v2, "e");
    try {
      graph.insert(v1, v2, "e");
      fail("The expected exception was not thrown");
    } catch (InsertionException ex) {
      return;
    }
  }

  @Test
  @DisplayName("insert(null) throws exception")
  public void insertVertexThrowsInsertionExceptionWhenNull() {
    try {
      graph.insert(null);
      fail("The expected exception was not thrown");
    } catch (InsertionException ex) {
      return;
    }
  }

  @Test
  @DisplayName("insert(v) twice throws exception")
  public void insertVertexThrowsInsertionExceptionWhenDuplicateVertex() {
    graph.insert("v");
    try {
      graph.insert("v");
      fail("The expected exception was not thrown");
    } catch (InsertionException ex) {
      return;
    }
  }

  @Test
  @DisplayName("remove(null) throws exception")
  public void removeVertexThrowsInsertionExceptionWhenNull() {
    try {
      graph.insert(null);
      fail("The expected exception was not thrown");
    } catch (InsertionException ex) {
      return;
    }
  }

  @Test
  @DisplayName("remove(V, null, e) throws exception")
  public void removeEdgeThrowsPositionExceptionWhenSecondVertexIsNull() {
    try {
      Vertex<String> v = graph.insert("v");
      graph.insert(v, null, "e");
      fail("The expected exception was not thrown");
    } catch (PositionException ex) {
      return;
    }
  }

  @Test
  @DisplayName("remove(v) removes vertex if it has no edges")
  public void removeVertexWithoutEdges() {
    Vertex<String> v = graph.insert("v1");
    assertEquals("v1", graph.remove(v));
  }

  @Test
  @DisplayName("remove(v) removes correct vertex if it has no edges")
  public void removeCorrectVertexWithoutEdges() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    assertEquals("v1", graph.remove(v1));
  }

  @Test
  @DisplayName("remove(v) throws PositionException if vertex is null")
  public void removeVertexThrowsPositionExceptionIfNull() {
    try {
      graph.remove((Vertex<String>) null);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("remove(v) throws PositionException if vertex is in other graph")
  public void removeVertexThrowsPositionExceptionIfInOtherGraph() {
    Graph<String, String> other = createGraph();
    Vertex<String> otherVertex = other.insert("X");

    try {
      graph.remove((otherVertex));
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("remove(v) throws PositionException if vertex has incident edge")
  public void removeVertexThrowsInsertionExceptionWhenIncidentEdge() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    graph.insert(v1, v2, "v1-v2");

    try {
      graph.remove(v1);
      fail("The expected exception was not thrown");
    } catch (RemovalException ex) {
      return;
    }
  }

  @Test
  @DisplayName("remove(v) throws PositionException if vertex has incident edge")
  public void removeVertexThrowsRemovalExceptionWhenIncidentEdgeOtherCase() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    graph.insert(v1, v2, "v1-v2");

    try {
      graph.remove(v2);
      fail("The expected exception was not thrown");
    } catch (RemovalException ex) {
      return;
    }
  }

  @Test
  @DisplayName("insert(v) works after remove(v)")
  public void insertWorksAfterRemoveForVertex() {
    Vertex<String> v1 = graph.insert("v1");
    assertEquals("v1", graph.remove(v1));
    v1 = graph.insert("v1.1");
    assertEquals("v1.1", v1.get());
  }

  @Test
  @DisplayName("remove edge works works")
  public void removeEdgeWorks() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    assertEquals("v1-v2", graph.remove(e1));
  }

  @Test
  @DisplayName("remove(e) throws PositionException if edge is null")
  public void removeEdgeThrowsPositionExceptionIfNull() {
    try {
      graph.remove((Edge<String>) null);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("remove(e) throws PositionException if edge is in other graph")
  public void removeEdgeThrowsPositionExceptionIfInOtherGraph() {
    Graph<String, String> other = createGraph();
    Vertex<String> v1 = other.insert("v1");
    Vertex<String> v2 = other.insert("v2");
    Edge<String> otherEdge = other.insert(v1, v2, "v1-v2");

    try {
      graph.remove((otherEdge));
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("insert(e) works after remove(e)")
  public void insertWorksAfterRemoveForEdge() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    assertEquals("v1-v2", graph.remove(e1));
    e1 = graph.insert(v1, v2, "v1-v2.1");
    assertEquals("v1-v2.1", e1.get());
  }

  @Test
  @DisplayName("remove(v) works after remove(e)")
  public void removeVertexWorksAfterIncidentEdgeRemoved() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    assertEquals("v1-v2", graph.remove(e1));
    assertEquals("v1", graph.remove(v1));
  }

  @Test
  @DisplayName("vertices() returns empty iterable when graph is empty")
  public void testVerticesEmptyGraph() {
    Iterable<Vertex<String>> vertices = graph.vertices();
    assertNotNull(vertices);
    assertFalse(vertices.iterator().hasNext());
  }

  @Test
  @DisplayName("vertices() returns vertex after one insertion")
  public void testVerticesOneVertex() {
    Vertex<String> v1 = graph.insert("v1");
    Iterable<Vertex<String>> vertices = graph.vertices();
    List<String> vertexData = new ArrayList<>();
    for (Vertex<String> vertex : vertices) {
      vertexData.add(vertex.get());
    }
    assertEquals(1, vertexData.size());
    assertTrue(vertexData.contains("v1"));
  }

  @Test
  @DisplayName("vertices() returns vertices after multiple insertions")
  public void testVerticesMultipleVertices() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Vertex<String> v3 = graph.insert("v3");
    Iterable<Vertex<String>> vertices = graph.vertices();
    List<String> vertexData = new ArrayList<>();
    for (Vertex<String> vertex : vertices) {
      vertexData.add(vertex.get());
    }
    assertEquals(3, vertexData.size());
    assertTrue(vertexData.contains("v1"));
    assertTrue(vertexData.contains("v2"));
    assertTrue(vertexData.contains("v3"));
  }

  @Test
  @DisplayName("vertices() returns vertices after removal")
  public void testVerticesAfterRemoval() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Vertex<String> v3 = graph.insert("v3");
    graph.remove(v1);
    Iterable<Vertex<String>> vertices = graph.vertices();
    List<String> vertexData = new ArrayList<>();
    for (Vertex<String> vertex : vertices) {
      vertexData.add(vertex.get());
    }
    assertEquals(2, vertexData.size());
    assertFalse(vertexData.contains("v1"));
    assertTrue(vertexData.contains("v2"));
    assertTrue(vertexData.contains("v3"));
  }

  @Test
  @DisplayName("edges() returns empty iterable when graph is empty")
  public void testEdgesEmptyGraph() {
    Iterable<Edge<String>> edges = graph.edges();
    assertNotNull(edges);
    assertFalse(edges.iterator().hasNext());
  }

  @Test
  @DisplayName("edges() returns edge after one insertion")
  public void testEdgesOneEdge() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    Iterable<Edge<String>> edges = graph.edges();
    List<String> edgeData = new ArrayList<>();
    for (Edge<String> edge : edges) {
      edgeData.add(edge.get());
    }
    assertEquals(1, edgeData.size());
    assertTrue(edgeData.contains("v1-v2"));
  }

  @Test
  @DisplayName("edges() returns edges after multiple insertions")
  public void testEdgesMultipleEdges() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Vertex<String> v3 = graph.insert("v3");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    Edge<String> e2 = graph.insert(v2, v3, "v2-v3");
    Iterable<Edge<String>> edges = graph.edges();
    List<String> edgeData = new ArrayList<>();
    for (Edge<String> edge : edges) {
      edgeData.add(edge.get());
    }
    assertEquals(2, edgeData.size());
    assertTrue(edgeData.contains("v1-v2"));
    assertTrue(edgeData.contains("v2-v3"));

  }

  @Test
  @DisplayName("edges() returns edges after removal")
  public void testEdgesAfterRemoval() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Vertex<String> v3 = graph.insert("v3");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    Edge<String> e2 = graph.insert(v2, v3, "v2-v3");
    graph.remove(e1);
    Iterable<Edge<String>> edges = graph.edges();
    List<String> edgeData = new ArrayList<>();
    for (Edge<String> edge : edges) {
      edgeData.add(edge.get());
    }
    assertEquals(1, edgeData.size());
    assertFalse(edgeData.contains("v1-v2"));
    assertTrue(edgeData.contains("v2-v3"));
  }

  @Test
  @DisplayName("outgoing() returns empty iterable when graph is empty")
  public void testOutgoingEmptyGraph() {
    Vertex<String> v1 = graph.insert("v1");
    Iterable<Edge<String>> outgoingEdges = graph.outgoing(v1);
    assertNotNull(outgoingEdges);
    assertFalse(outgoingEdges.iterator().hasNext());
  }

  @Test
  @DisplayName("outgoing() returns edge after one insertion")
  public void testOutgoingOneEdge() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    Iterable<Edge<String>> outgoingEdges = graph.outgoing(v1);
    List<String> edgeData = new ArrayList<>();
    for (Edge<String> edge : outgoingEdges) {
      edgeData.add(edge.get());
    }
    assertEquals(1, edgeData.size());
    assertTrue(edgeData.contains("v1-v2"));
  }

  @Test
  @DisplayName("outgoing() returns edges after multiple insertions")
  public void testOutgoingMultipleEdges() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Vertex<String> v3 = graph.insert("v3");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    Edge<String> e2 = graph.insert(v1, v3, "v1-v3");
    Iterable<Edge<String>> outgoingEdges = graph.outgoing(v1);
    List<String> edgeData = new ArrayList<>();
    for (Edge<String> edge : outgoingEdges) {
      edgeData.add(edge.get());
    }
    assertEquals(2, edgeData.size());
    assertTrue(edgeData.contains("v1-v2"));
    assertTrue(edgeData.contains("v1-v3"));

  }

  @Test
  @DisplayName("outgoing() returns edges after removal")
  public void testOutgoingAfterRemoval() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Vertex<String> v3 = graph.insert("v3");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    Edge<String> e2 = graph.insert(v1, v3, "v1-v3");
    graph.remove(e1);
    Iterable<Edge<String>> outgoingEdges = graph.outgoing(v1);
    List<String> edgeData = new ArrayList<>();
    for (Edge<String> edge : outgoingEdges) {
      edgeData.add(edge.get());
    }
    assertEquals(1, edgeData.size());
    assertFalse(edgeData.contains("v1-v2"));
    assertTrue(edgeData.contains("v1-v3"));
  }

  @Test
  @DisplayName("outgoing() throws PositionException if null")
  public void testOutgoingThrowsPositionExceptionIfNull() {

    try {
      graph.outgoing(null);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("outgoing() throws PositionException if vertex in other graph")
  public void testOutgoingThrowsIfInOtherGraph() {
    Graph<String,String> other = createGraph();
    Vertex<String> otherVertex = other.insert("X");
    try {
      graph.outgoing(otherVertex);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("incoming() returns empty iterable when graph is empty")
  public void testIncomingEmptyGraph() {
    Vertex<String> v1 = graph.insert("v1");
    Iterable<Edge<String>> incomingEdges = graph.incoming(v1);
    assertNotNull(incomingEdges);
    assertFalse(incomingEdges.iterator().hasNext());
  }

  @Test
  @DisplayName("incoming() returns edge after one insertion")
  public void testIncomingOneEdge() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    Iterable<Edge<String>> incomingEdges = graph.incoming(v2);
    List<String> edgeData = new ArrayList<>();
    for (Edge<String> edge : incomingEdges) {
      edgeData.add(edge.get());
    }
    assertEquals(1, edgeData.size());
    assertTrue(edgeData.contains("v1-v2"));
  }

  @Test
  @DisplayName("incoming() returns edges after multiple insertions")
  public void testIncomingMultipleEdges() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Vertex<String> v3 = graph.insert("v3");
    Edge<String> e1 = graph.insert(v2, v1, "v2-v1");
    Edge<String> e2 = graph.insert(v3, v1, "v3-v1");
    Iterable<Edge<String>> incomingEdges = graph.incoming(v1);
    List<String> edgeData = new ArrayList<>();
    for (Edge<String> edge : incomingEdges) {
      edgeData.add(edge.get());
    }
    assertEquals(2, edgeData.size());
    assertTrue(edgeData.contains("v2-v1"));
    assertTrue(edgeData.contains("v3-v1"));

  }

  @Test
  @DisplayName("incoming() returns edges after removal")
  public void testIncomingAfterRemoval() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Vertex<String> v3 = graph.insert("v3");
    Edge<String> e1 = graph.insert(v2, v1, "v2-v1");
    Edge<String> e2 = graph.insert(v3, v1, "v3-v1");
    graph.remove(e1);
    Iterable<Edge<String>> incomingEdges = graph.incoming(v1);
    List<String> edgeData = new ArrayList<>();
    for (Edge<String> edge : incomingEdges) {
      edgeData.add(edge.get());
    }
    assertEquals(1, edgeData.size());
    assertFalse(edgeData.contains("v2-v1"));
    assertTrue(edgeData.contains("v3-v1"));
  }

  @Test
  @DisplayName("incoming() throws PositionException if null")
  public void testIncomingThrowsPositionExceptionIfNull() {

    try {
      graph.incoming(null);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("incoming() throws PositionException if vertex in other graph")
  public void testIncomingThrowsIfInOtherGraph() {
    Graph<String,String> other = createGraph();
    Vertex<String> otherVertex = other.insert("X");
    try {
      graph.incoming(otherVertex);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("from() throws PositionException if edge in other graph")
  public void testFromThrowsIfInOtherGraph() {
    Graph<String,String> other = createGraph();
    Vertex<String> v1 = other.insert("v1");
    Vertex<String> v2 = other.insert("v2");
    Edge<String> e = other.insert(v1, v2, "v1-v2");

    try {
      graph.from(e);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("from() returns from vertex")
  public void testFromReturnsFromVertex() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e = graph.insert(v1, v2, "v1-v2");
    assertEquals(v1, graph.from(e));
  }

  @Test
  @DisplayName("from() throws PositionException if edge is null")
  public void testFromThrowsIfNull() {
    try {
      graph.from(null);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("from() throws PositionException if edge removed")
  public void testFromThrowsIfEdgeRemoved() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e = graph.insert(v1, v2, "v1-v2");
    graph.remove(e);

    try {
      graph.from(e);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("to() throws PositionException if edge in other graph")
  public void testToThrowsIfInOtherGraph() {
    Graph<String,String> other = createGraph();
    Vertex<String> v1 = other.insert("v1");
    Vertex<String> v2 = other.insert("v2");
    Edge<String> e = other.insert(v1, v2, "v1-v2");

    try {
      graph.to(e);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("to() returns to vertex")
  public void testToReturnsToVertex() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e = graph.insert(v1, v2, "v1-v2");
    assertEquals(v2, graph.to(e));
  }

  @Test
  @DisplayName("to() throws PositionException if edge is null")
  public void testToThrowsIfNull() {
    try {
      graph.to(null);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("to() throws PositionException if edge removed")
  public void testToThrowsIfEdgeRemoved() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e = graph.insert(v1, v2, "v1-v2");
    graph.remove(e);

    try {
      graph.to(e);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("label(v, l) adds label to vertex")
  public void testLabelAddsLabelToVertex() {
    Vertex<String> v1 = graph.insert("v1");
    graph.label(v1,"word");
    assertEquals("word", graph.label(v1));
  }

  @Test
  @DisplayName("label(v, l) relabels vertex")
  public void testLabelRelabelsVertex() {
    Vertex<String> v1 = graph.insert("v1");
    graph.label(v1,"word");
    graph.label(v1,"word2");
    assertEquals("word2", graph.label(v1));
  }

  @Test
  @DisplayName("label(v, l) adds null label to vertex")
  public void testLabelAddsNullLabelToVertex() {
    Vertex<String> v1 = graph.insert("v1");
    graph.label(v1,null);
    assertNull(graph.label(v1));
  }

  @Test
  @DisplayName("label(v, l) throws PositionException if vertex null")
  public void testLabelThrowsIfVertexNull() {
    try {
      graph.label((Vertex<String>) null, "word");
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("label(v, l) throws PositionException if vertex in other graph")
  public void testLabelThrowsIfVertexInOtherGraph() {
    Graph<String,String> other = createGraph();
    Vertex<String> v1 = other.insert("v1");

    try {
      graph.label(v1, "word");
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("label(v, l) adds different label types to vertices")
  public void testLabelAddsDifferentTypeLabelsToVertex() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    graph.label(v1,"word");
    graph.label(v2,5);
    assertEquals("word", graph.label(v1));
    assertEquals(5, graph.label(v2));
  }

  @Test
  @DisplayName("label(e, l) relabels edge")
  public void testLabelRelabelsEdge() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e = graph.insert(v1, v2, "v1-v2");
    graph.label(e,"word");
    graph.label(e,"word2");
    assertEquals("word2", graph.label(e));
  }

  @Test
  @DisplayName("label(e, l) adds null label to edge")
  public void testLabelAddsNullLabelToEdge() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e = graph.insert(v1, v2, "v1-v2");
    graph.label(e,null);
    assertNull(graph.label(e));
  }

  @Test
  @DisplayName("label(e, l) throws PositionException if edge null")
  public void testLabelThrowsIfEdgeNull() {
    try {
      graph.label((Edge<String>) null, "word");
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("label(e, l) adds different label types to edges")
  public void testLabelAddsDifferentTypeLabelsToEdge() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Vertex<String> v3 = graph.insert("v3");
    Edge<String> e1 = graph.insert(v1, v2, "v1-v2");
    Edge<String> e2 = graph.insert(v1, v3, "v1-v2");
    graph.label(e1,"word");
    graph.label(e2,5);
    assertEquals("word", graph.label(e1));
    assertEquals(5, graph.label(e2));
  }


  @Test
  @DisplayName("label(e, l) adds label to edge")
  public void testLabelAddsLabelToEdge() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e = graph.insert(v1, v2, "v1-v2");
    graph.label(e,"word");
    assertEquals("word", graph.label(e));
  }

  @Test
  @DisplayName("label(e, l) throws PositionException if edge in other graph")
  public void testLabelThrowsIfEdgeInOtherGraph() {
    Graph<String,String> other = createGraph();
    Vertex<String> v1 = other.insert("v1");
    Vertex<String> v2 = other.insert("v2");
    Edge<String> e = other.insert(v1, v2, "v1-v2");

    try {
      graph.label(e, "word");
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("label(v) throws PositionException if vertex null")
  public void testGetLabelThrowsIfVertexNull() {
    try {
      graph.label((Vertex<String>) null);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("label(v) returns null by default for a new vertex")
  public void testLabelVertexDefaultNull() {
    Vertex<String> v1 = graph.insert("v1");
    assertNull(graph.label(v1));
  }

  @Test
  @DisplayName("label(v) throws PositionException if vertex in other graph")
  public void testGetLabelThrowsIfVertexInOtherGraph() {
    Graph<String,String> other = createGraph();
    Vertex<String> v1 = other.insert("v1");
    other.label(v1, "word");
    try {
      graph.label(v1);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("label(e) throws PositionException if edge null")
  public void testGetLabelThrowsIfEdgeNull() {
    try {
      graph.label((Edge<String>) null);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("label(e) returns null by default for a new edge")
  public void testLabelEdgeDefaultNull() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e = graph.insert(v1,v2,"v1-v2");
    assertNull(graph.label(e));
  }

  @Test
  @DisplayName("label(e) throws PositionException if edge in other graph")
  public void testGetLabelThrowsIfEdgeInOtherGraph() {
    Graph<String,String> other = createGraph();
    Vertex<String> v1 = other.insert("v1");
    Vertex<String> v2 = other.insert("v2");
    Edge<String> e = other.insert(v1, v2, "v1-v2");

    try {
      graph.label(e);
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("clearLabels() clears labels from vertices and edges")
  public void testClearLabelsClearsAllLabels() {
    Vertex<String> v1 = graph.insert("v1");
    Vertex<String> v2 = graph.insert("v2");
    Edge<String> e = graph.insert(v1, v2, "e");

    graph.label(v1, "word");
    graph.label(v2, "word2");
    graph.label(e, 5);

    graph.clearLabels();

    assertNull(graph.label(v1));
    assertNull(graph.label(v2));
    assertNull(graph.label(e));
  }

  @Test
  @DisplayName("insert(v,v, e) throws PositionException if one vertex in other graph")
  public void testInsertEdgeThrowsIfFirstVertexInOtherGraph() {
    Graph<String,String> other = createGraph();
    Vertex<String> otherVertex = other.insert("X");
    Vertex<String> v2 = graph.insert("v2");

    try {
      Edge<String> e = graph.insert(otherVertex, v2, "e");
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }

  @Test
  @DisplayName("insert(v,v, e) throws PositionException if second vertex in other graph")
  public void testInsertEdgeThrowsIfSecondVertexInOtherGraph() {
    Graph<String,String> other = createGraph();
    Vertex<String> otherVertex = other.insert("X");
    Vertex<String> v1 = graph.insert("v1");

    try {
      Edge<String> e = graph.insert(v1, otherVertex, "e");
      fail("Expected PositionException");
    } catch (PositionException ex) {
      //return;
    }
  }





}
