# Homework 1 Discussion

## Part I: Object-Oriented Programming Concepts

1. **Class**: A class is a template for different objects. For example in the
game FlappyBox is a class that can be used to make flappy box objects. This class
has methods and attributes that pertain to the flappy box such as jump velocity.

2. **Object**: An object is an instance of a class where the class is given
specific attributes. For example in my code I have the line: flappyBox = new FlappyBox
where I initialize an object of the FlappyBox class. flappyBox is an instance of 
FlappyBox, and it has specific attributes.

3. **Encapsulation**: Encapsulation is the act of making certain attributes or methods
private so that other parts of the code are not able to access them. For example in
Block.java all the attributes are set to private ex: private double topLeftX;
This means topLeftX can not be accessed outside the scope of the block class and would
need another method to set or get topLeftX.

4. **Abstraction**: Abstraction is hiding the way that the code works from the user and
only showing what is needed. This can be done by using abstract classes or interfaces.
An example of this is the Block class which is an abstract class. This means that it 
can not be used to create objects which keeps the data hidden from the user.

5. **Data type**: Data types are the way that a variable is stored in the memory. Some
examples are int, boolean, classes, and more. For example: private double topLeftX; means that 
the variable topLeftX is of type double which means that the number that is stored in
topLeftX can be a fraction and doubles can have a larger range as well.

6. **Composite data type**: A composite data type is a collection of other data types.
This can be something such as an array or list. It stores more than one thing and so it
is composite, and it is a data type as those items inside it have data types. An example
of this is in Pipe: private Box[] boxes; The notation of Box[] makes an array called boxes.
This array is then filled with data of the type Box.

7. **Method**: A method is part of a class, and they preform actions in a class. They can 
access or take in variables and use them to return something. An example of this is:
public double getJumpVelocity() { return jumpVelocity; } which returns a double and can
be called by objects of the class.

8. **Constructor**: They are a type of method that is used to initialize the attributes for
a specific object. They can take in values to initialize the attributes to and are called 
when making an object. An example of this is in FlappyBox: public FlappyBox(double x, double y)
it then goes on to initialize x, y, and another variable called jumpVelocity.

9. **Instance variable**: An instance variable is a variable that is declared in a class but
outside any methods or constructors. An example is: protected double jumpVelocity; This is 
declared outside any constructors or methods.

10. **Local variable**: A local variable is a variable that is declared inside a method and
so it is only available in the scope of that method. An example is: pipe.move(); inside the
moveGameObjects() method. The pipe variable is a local variable as it is only in scope in
that one method. More particularly it is only in scope of the for loop inside the method.

11. **Parameter**: Parameters are variables that are passed into a method/constructor. An example
in the game is: public FlappyBox(double x, double y), in this case x and y are parameters for the
FlappyBox method. As this is a constructor they will then get initialized to attributes of
FlappyBox

12. **Return type**: The return type is stating for a method what will be returned. This can be
any type of data type and is stated in the method declaration. An example of this is:
public double getJumpVelocity() { return jumpVelocity; } The second word, double, is what tells us
what time type will be returned from this method.

13. **Inheritance**: It is the act of a class inheriting or getting methods and attributes from a
"parent" class. This can be used to make a more specific class that has the same thing as another
class, but it also has some other methods or overwritten methods of that base class. An example of
this can be seen in the FlappyBox class which extends the FallingBox class. That means that it has
attributes and methods of the FallingBox class however it has some added functionality.

14. **Type Hierarchy**: Type hierarchy is the way that one class is the base type of another class
which would be then be the subtype of that base type. Such as a dog is a type of mammal and so the
hierarchy would be mammal as the base type and dog as the subtype. The type hierarchy of the
project from base to subtype is: GameObject, Block, Sprite, Box, FallingBox, FlappyBox. there is
also another branch at box to pipe.

15. **Apparent type**: The apparent type of a variable is what it is declared as. It appears to
be the type that it was declared as however if the actual type does not match then it can
actually be a different type. For example: private FlappyBox flappyBox, the apparent type is
FlappyBox.

16. **Actual type**: The actual type is set when you instantiate the variable. For example:
flappyBox = new FlappyBox(...), causes the actual type to be FlappyBox. In this case the 
apparent type and the actual type are the same.

17. **Is-a relationship**: An is-a relationship is a type of hierarchy where one class belongs
to another class. A dog is a mammal so the dog and mammal have an is-a relationship. For example
in the game the FlappyBox is a FallingBox so they have an is-a relationship.

18. **Has-a relationship**: A has-a relationship is a type of hierarchy where one class has
another class. A car has a motor so they have a has-a relationship. For example:
FlappyBoxDemo has a FlappyBox which is a has-a relationship.

19. **Method overloading**: Method overloading is where more than one method has the same name
however they have different parameters. This allows for a method to be called for different 
data types while still keeping the name the same to make writing the code more clear. An
example of this is in the StdDraw file where setPenColor has two different methods:
setPenColor(Color color) and setPenColor(int red, int green, int blue). While they both have
the same method name they have different parameters which allows for the overloading.

20. **Method overriding**: Method overriding is where even though a method is inherited from
a base class it is overridden to do something different in the subclass. For example in pipe
intersect is overridden and new code is written for that method so that when pipe.intersect()
is called it will properly work. 

21. **Static polymorphism**: Static polymorphism means that it is resolved at compile time as
when the code is compiled the compiler links the call to the correct method. An example of this
is calling a method that is not overridden and so the compiler knows which call is being used.
An example in the game is: displayScore(); as the compiler knows to call the only version of
displayScore().

22. **Dynamic polymorphism**: Dynamic polymorphism means that it is resolved at runtime as the
compiler is unsure which method to link some code to. This can be explained by an overridden 
method as the compiler is unsure which method will actually be carried out. AN example in the
game is: pipe.move(); as there is a move method in sprite and in Pipe. The move in Pipe is
overridden and so the compiler does not know which move will be used when Pipe.move() is
called. Thus, the JVM decides at runtime which method to call.

## Part II: Data Structures
An example of a data structure used in the game is an array. This can be seen in the pipe
class: private Box[] boxes;, this is the declaration for the array and then the array
is initialized with the line: boxes = new Box[GameConstant.BOX_IN_PIPE];. An array is
used for the pipes in the game as the pipes are actually multiple boxes and so it makes
sense to have a data structure that is able to hold the multiple box objects for each pipe
so that they can be more organized and easier to work with. Additionally, the number of
boxes in the pipe is known so the size of the pipe array will not be changing so it is
fine to use an array.

Another data structure in the game is a list. This can be seen in the MovingPipeDemo class:
private List<Pipe> pipes; this is how it is declared however it needs to be initialized and
so the line pipes = new ArrayList<>(); initializes the list as an ArrayList which means that
it is now an array that is dynamic as it is a list. How it is dynamic that means that data
can be added and removed from it, and it will grow or shrink. This is opposed to regular
arrays where the size of the array needs to be mentioned when it is initialized. This is 
used in this project because pipe objects are being added and removed from pipes and so
a data structure that can be modified is needed. ArrayLists can be modified and so it is
used in the game and helps with keeping the pipe objects organized.


## Part III: Algorithm Example
An algorithm used in the game is updateScore as it solves the problem of seeing what the
score is and updating it if it is necessary. It does this by checking if there are any
pipes to the left of the flappy box and also checking if flappy box has not already
passed the pipe by using a boolean in pipe that denotes if flappy box has already
passed it. If those conditions are both true then the score is incremented by one
and the pipe is noted as passed. This helps the game as it allows for an easy
way to check if the pipes should be counted or not and updates the score if
needed.