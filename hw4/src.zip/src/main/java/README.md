# Discussion

# Part 1
I had an issue with pathing and did not have enough time to solve it. I would assume the
AVL tree to be more consistent as it is ensuring it is maintaining a consistent tree that is
balanced while trap can get out of balance for some cases. This consistancy would most likely
lead to better preformance most of the time but, it could also lead to more time as it would need
to balance the tree after most or some insertions where a treap may not need to be balancing as often.


# Part 2
Strategy 1 is correct and will work as by placing the elements into a max heap
they will be sorted with largest at the top and smallest towards the bottom.
Then by removing the element that is at the root the next largest element will
move to the root spot. This means that after k removals the element at the root
will be the kth largest element.
The time complexity would be o(n) for placing all the elements into the heap, then
remove takes o(log n) time as it needs to swap the first with the last and bubble
the piece into the correct place. It will do this k times so it will be o(k log n)
so total this will be O(n + k*log n). which should simplify down to O(n) time complexity.
The space complexity will be O(n) as the input space will be O(n) for the inputs and then 
the heap will store O(n) as it stores all the elements. This will simplify to O(n).

Stately 2 is also correct as by inserting the first k elements into the heap it will be the
largest elements that have been seen thus far with the smallest being the root. Then if an
element that has not been seen yet is larger than the min that value is removed as it is no
longer in the k largest elements and the larger one is inserted. Once the whole data has been
gone through the tree will be the k largest elements with the root being the smallest aka the 
kth from the largest value.
The time complexity for this: O(log k) is for insert as that is the time complexity, and it will
be done k times so total of O(k * log k). then comparing takes O(1) and inserting will take 
O((n-k) * log k); which when added to O(k * log k) becomes just O(n * log k)
The space complexity is O(n) for the inputs and then O(k) for the heap/ auxiliary space. 
Thus, the auxiliary space is O(k) and the space complexity including the input is O(n).

