package hw4;

import java.util.Iterator;
import java.util.Stack;

/**
 * Map implemented as an AVL Tree.
 *
 * @param <K> Type for keys.
 * @param <V> Type for values.
 */
public class AvlTreeMap<K extends Comparable<K>, V> implements OrderedMap<K, V> {

  /*** Do not change variable name of 'root'. ***/
  private Node<K, V> root;
  private int size;

  @Override
  public void insert(K k, V v) throws IllegalArgumentException {
    if (k == null) {
      throw new IllegalArgumentException("null key not permitted");
    }

    root = insert(root, k, v);
  }

  //helper function that uses recursion to insert the node in the correct place
  private Node<K, V> insert(Node<K, V> node, K k, V v) {
    if (node == null) {
      size++;
      return new Node<>(k, v);
    }

    //check where it should be inserted and checks for duplicates
    if (node.key.compareTo(k) > 0) {
      node.left = insert(node.left, k, v);
    } else if (node.key.compareTo(k) < 0) {
      node.right = insert(node.right, k, v);
    } else {
      throw new IllegalArgumentException("duplicate key " + k);
    }

    //update the height after the node is added
    updateHeight(node);

    //check if the tree needs to balanced and return the new node after balancing
    return balanceTree(node);
  }


  @Override
  public V remove(K k) throws IllegalArgumentException {
    if (root == null || k == null) {
      throw new IllegalArgumentException("null key not permitted / null key not permitted");
    }

    Node<K, V> node = findForSure(k);
    V value = node.value;
    root = remove(root, node);
    size--;
    return value;
  }

  // Remove node with given key from subtree rooted at given node;
  // Return changed subtree with given key missing.
  private Node<K, V> remove(Node<K, V> subtreeRoot, Node<K, V> toRemove) {
    int cmp = subtreeRoot.key.compareTo(toRemove.key);
    if (cmp == 0) {
      return remove(subtreeRoot);
    } else if (cmp > 0) {
      subtreeRoot.left = remove(subtreeRoot.left, toRemove);
    } else {
      subtreeRoot.right = remove(subtreeRoot.right, toRemove);
    }

    updateHeight(subtreeRoot);

    return balanceTree(subtreeRoot);
  }

  // Remove given node and return the remaining tree (structural change).
  private Node<K, V> remove(Node<K, V> node) {
    // Easy if the node has 0 or 1 child.
    if (node.right == null) {
      return node.left;
    } else if (node.left == null) {
      return node.right;
    }

    // If it has two children, find the predecessor (max in left subtree),
    Node<K, V> toReplaceWith = max(node);
    // then copy its data to the given node (value change),
    node.key = toReplaceWith.key;
    node.value = toReplaceWith.value;
    // then remove the predecessor node (structural change).
    node.left = remove(node.left, toReplaceWith);

    return balanceTree(node);
  }

  // Return a node with maximum key in subtree rooted at given node.
  private Node<K, V> max(Node<K, V> node) {
    Node<K, V> curr = node.left;
    while (curr.right != null) {
      curr = curr.right;
    }
    return curr;
  }

  @Override
  public void put(K k, V v) throws IllegalArgumentException {
    if (k == null) {
      throw new IllegalArgumentException("null key not permitted");
    }

    Node<K, V> node = findForSure(k);
    node.value = v;
  }

  // Return node for given key,
  // throw an exception if the key is not in the tree.
  private Node<K, V> findForSure(K k) {
    Node<K, V> node = find(root, k);
    if (node == null || k == null) {
      throw new IllegalArgumentException("cannot find key " + k);
    }
    return node;
  }

  @Override
  public V get(K k) throws IllegalArgumentException {
    if (k == null) {
      throw new IllegalArgumentException("null key not permitted");
    }
    Node<K, V> node = findForSure(k);
    return node.value;
  }

  @Override
  public boolean has(K k) {
    if (k == null) {
      return false;
    }
    return find(root, k) != null;
  }

  // Return node for given key
  private Node<K, V> find(Node<K, V> node, K k) {
    if (node == null) {
      return null;
    }

    int cmp = k.compareTo(node.key);
    if (cmp < 0) {
      return find(node.left, k);
    } else if (cmp > 0) {
      return find(node.right, k);
    } else {
      return node;
    }
  }

  @Override
  public int size() {
    return size;
  }

  @Override
  public Iterator<K> iterator() {
    return new InorderIterator();
  }

  // Iterative in-order traversal over the keys
  private class InorderIterator implements Iterator<K> {
    private final Stack<Node<K, V>> stack;

    InorderIterator() {
      stack = new Stack<>();
      pushLeft(root);
    }

    private void pushLeft(Node<K, V> curr) {
      while (curr != null) {
        stack.push(curr);
        curr = curr.left;
      }
    }

    @Override
    public boolean hasNext() {
      return !stack.isEmpty();
    }

    @Override
    public K next() {
      Node<K, V> top = stack.pop();
      pushLeft(top.right);
      return top.key;
    }
  }


  //returns the height of the node and ensures no errors if node is null
  private int getHeight(Node<K, V> node) {
    if (node == null) {
      return -1;
    }
    return node.height;
  }

  //returns the height of the taller child plus 1 as it is one higher
  private void updateHeight(Node<K, V> node) {
    if (node == null) {
      return;
    }
    node.height = Math.max(getHeight(node.left), getHeight(node.right)) + 1;
  }

  //helper function to check if the tree is balanced and fix it
  private Node<K, V> balanceTree(Node<K, V> node) {

    int bf = getHeight(node.left) - getHeight(node.right);
    //System.out.println(node.value, "and", bf);
    //check if right turn needed
    if (bf > 1) {
      //check if left turn needed before the right turn
      if (getHeight(node.left.left) < getHeight(node.left.right)) {
        node.left = rotateLeft(node.left);
      }
      return rotateRight(node);
    }

    //check if a left turn needed
    if (bf < -1) {
      //check if right turn needed before the left turn
      if (getHeight(node.right.left) > getHeight(node.right.right)) {
        node.right = rotateRight(node.right);
      }
      return rotateLeft(node);
    }
    return node;
  }

  //helper function to preform right rotations
  private Node<K, V> rotateRight(Node<K, V> node) {

    //do the rotation
    Node<K, V> newRoot = node.left;
    node.left = newRoot.right;
    newRoot.right = node;

    //update heights so it does not cause issues
    updateHeight(node);
    updateHeight(newRoot);

    return newRoot;
  }

  //helper function to preform left rotations
  private Node<K, V> rotateLeft(Node<K, V> node) {

    //do the rotation
    Node<K, V> newRoot = node.right;
    node.right = newRoot.left;
    newRoot.left = node;

    //update heights so it does not cause issues
    updateHeight(node);
    updateHeight(newRoot);

    return newRoot;
  }


  /*** Do not change this function's name or modify its code. ***/
  @Override
  public String toString() {
    return BinaryTreePrinter.printBinaryTree(root);
  }

  /**
   * Inner node class, each holds a key (which is what we sort the
   * BST by) as well as a value. We don't need a parent pointer as
   * long as we use recursive insert/remove helpers.
   *
   * @param <K> Type for keys.
   * @param <V> Type for values.
   **/
  private static class Node<K, V> implements BinaryTreeNode {
    Node<K, V> left;
    Node<K, V> right;
    K key;
    V value;
    int height;

    // Constructor to make node creation easier to read.
    Node(K k, V v) {
      // left and right default to null
      key = k;
      value = v;
    }

    @Override
    public String toString() {
      return key + ":" + value;
    }

    @Override
    public BinaryTreeNode getLeftChild() {
      return left;
    }

    @Override
    public BinaryTreeNode getRightChild() {
      return right;
    }

    // Feel free to add whatever you want to the Node class (e.g. new fields).
    // Just avoid changing any existing names, deleting any existing variables, or modifying the overriding methods.
  }
}
