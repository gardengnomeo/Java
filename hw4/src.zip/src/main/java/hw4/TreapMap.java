package hw4;

import java.util.Iterator;
import java.util.Random;
import java.util.Stack;

/**
 * Map implemented as a Treap.
 *
 * @param <K> Type for keys.
 * @param <V> Type for values.
 */
public class TreapMap<K extends Comparable<K>, V> implements OrderedMap<K, V> {

  /*** Do not change variable name of 'rand'. ***/
  private static Random rand;
  /*** Do not change variable name of 'root'. ***/
  private Node<K, V> root;
  private int size;


  /**
   * Make a TreapMap.
   */
  public TreapMap() {
    rand = new Random();
  }

  /**
   * Make a TreapMap with a custom seed.
   *
   * @param seed The seed value to control randomness.
   */
  public TreapMap(long seed) {
    rand = new Random(seed); // Allows controlled priority generation for tests.
  }

  @Override
  public void insert(K k, V v) throws IllegalArgumentException {
    if (k == null) {
      throw new IllegalArgumentException("null key not permitted");
    }
    root = insert(root, k, v);
  }

  //helper function that uses recursion to insert the node in the correct place
  private Node<K, V> insert(Node<K, V> node, K k, V v) {
    if (node == null) {
      size++;
      return new Node<>(k, v);
    }

    //check where it should be inserted and checks for duplicates
    if (node.key.compareTo(k) > 0) {
      node.left = insert(node.left, k, v);

    } else if (node.key.compareTo(k) < 0) {
      node.right = insert(node.right, k, v);

    } else {
      throw new IllegalArgumentException("duplicate key " + k);
    }

    //check priority and rotate right if not correct
    if (node.left != null && node.left.priority < node.priority) {
      node = rotateRight(node);
    }

    //check priority and rotate left if not correct
    if (node.right != null && node.right.priority < node.priority) {
      node = rotateLeft(node);
    }

    return node;
  }


  @Override
  public V remove(K k) throws IllegalArgumentException {
    if (root == null || k == null) {
      throw new IllegalArgumentException("null key not permitted or root must not be null");
    }
    Node<K, V> node = findForSure(k);
    node.priority = Integer.MAX_VALUE;
    V value = node.value;
    root = remove(root, node);
    size--;
    return value;
  }

  // Remove node with given key from subtree rooted at given node;
  // Return changed subtree with given key missing.
  private Node<K, V> remove(Node<K, V> subtreeRoot, Node<K, V> toRemove) {

    int cmp = subtreeRoot.key.compareTo(toRemove.key);
    if (cmp == 0) { //when node is found call the remove function
      return remove(subtreeRoot);
    } else if (cmp > 0) {
      subtreeRoot.left = remove(subtreeRoot.left, toRemove);
    } else {
      subtreeRoot.right = remove(subtreeRoot.right, toRemove);
    }

    return subtreeRoot;
  }

  // Remove given node and return the remaining tree (structural change).
  private Node<K, V> remove(Node<K, V> node) {

    //has no children
    if (node.left == null && node.right == null) {
      return null;
    }

    //if there is only one child
    if (node.left == null) {
      return node.right;
    }
    if (node.right == null) {
      return node.left;
    }

    //rotate nodes ot remove it
    if (node.left.priority < node.right.priority) {
      node = rotateRight(node);
      node.right = remove(node.right);
    } else {
      node = rotateLeft(node);
      node.left = remove(node.left);
    }
    return node;
  }






  @Override
  public void put(K k, V v) throws IllegalArgumentException {
    if (k == null) {
      throw new IllegalArgumentException("null key not permitted");
    }

    Node<K, V> node = findForSure(k);
    node.value = v;
  }

  @Override
  public V get(K k) throws IllegalArgumentException {
    if (k == null) {
      throw new IllegalArgumentException("null key not permitted");
    }
    Node<K, V> node = findForSure(k);
    return node.value;
  }

  // Return node for given key,
  // throw an exception if the key is not in the tree.
  private Node<K, V> findForSure(K k) {
    Node<K, V> node = find(root, k);
    if (node == null) {
      throw new IllegalArgumentException("cannot find key " + k);
    }
    return node;
  }

  @Override
  public boolean has(K k) {
    if (k == null) {
      return false;
    }
    return find(root, k) != null;
  }

  // Return node for given key
  private Node<K, V> find(Node<K, V> node, K k) {
    if (node == null) {
      return null;
    }

    int cmp = k.compareTo(node.key);
    if (cmp < 0) {
      return find(node.left, k);
    } else if (cmp > 0) {
      return find(node.right, k);
    } else {
      return node;
    }
  }

  @Override
  public int size() {
    return size;
  }

  @Override
  public Iterator<K> iterator() {
    return new InorderIterator();
  }

  // Iterative in-order traversal over the keys
  private class InorderIterator implements Iterator<K> {
    private final Stack<Node<K, V>> stack;

    InorderIterator() {
      stack = new Stack<>();
      pushLeft(root);
    }

    private void pushLeft(Node<K, V> curr) {
      while (curr != null) {
        stack.push(curr);
        curr = curr.left;
      }
    }

    @Override
    public boolean hasNext() {
      return !stack.isEmpty();
    }

    @Override
    public K next() {
      Node<K, V> top = stack.pop();
      pushLeft(top.right);
      return top.key;
    }
  }

  /*** Do not change this function's name or modify its code. ***/
  @Override
  public String toString() {
    return BinaryTreePrinter.printBinaryTree(root);
  }

  //helper function to preform right rotations
  private Node<K, V> rotateRight(Node<K, V> node) {

    //do the rotation
    Node<K, V> newRoot = node.left;
    node.left = newRoot.right;
    newRoot.right = node;

    return newRoot;
  }

  //helper function to preform left rotations
  private Node<K, V> rotateLeft(Node<K, V> node) {

    //do the rotation
    Node<K, V> newRoot = node.right;
    node.right = newRoot.left;
    newRoot.left = node;

    return newRoot;
  }


  /**
   * Inner node class, each holds a key (which is what we sort the
   * BST by) as well as a value. We don't need a parent pointer as
   * long as we use recursive insert/remove helpers. Since this is
   * a node class for a Treap we also include a priority field.
   *
   * @param <K> Type for keys.
   * @param <V> Type for values.
   **/
  private static class Node<K, V> implements BinaryTreeNode {
    Node<K, V> left;
    Node<K, V> right;
    K key;
    V value;
    int priority;

    // Constructor to make node creation easier to read.
    Node(K k, V v) {
      // left and right default to null
      key = k;
      value = v;
      priority = generateRandomInteger();
    }

    // Use this function to generate random values
    // to use as node priorities as you insert new
    // nodes into your TreapMap.
    private int generateRandomInteger() {
      // Note: do not change this function!
      return rand.nextInt();
    }

    //helper function for bounded random number
    private int generateRandomInteger(int bound) {
      return rand.nextInt(bound);
    }

    @Override
    public String toString() {
      return key + ":" + value + ":" + priority;
    }

    @Override
    public BinaryTreeNode getLeftChild() {
      return left;
    }

    @Override
    public BinaryTreeNode getRightChild() {
      return right;
    }

    // Feel free to add whatever you want to the Node class (e.g. new fields).
    // Just avoid changing any existing names, deleting any existing variables, or modifying the overriding methods.
  }
}
