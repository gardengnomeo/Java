package hw4;

import exceptions.EmptyException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Priority queue implemented as a binary heap with a ranked array representation.
 *
 * @param <T> Element type.
 */
public class BinaryHeapPriorityQueue<T extends Comparable<T>> implements PriorityQueue<T> {
  private final List<T> heap;
  private Comparator<T> cmp;

  /**
   * Make a BinaryHeapPriorityQueue.
   */
  public BinaryHeapPriorityQueue() {
    this(new DefaultComparator<>());
  }

  /**
   * Make a BinaryHeapPriorityQueue with a custom comparator.
   *
   * @param cmp Comparator to use.
   */
  public BinaryHeapPriorityQueue(Comparator<T> cmp) {
    this.cmp = cmp;
    heap = new ArrayList<>();
    heap.add(null); // Add a dummy element at index 0 to simplify arithmetic
  }

  @Override
  public void insert(T t) {
    if (t == null) {
      throw new IllegalArgumentException("Cannot insert null value");
    }

    heap.add(t);

    //start at end of the list with element just added
    int index = heap.size() - 1;

    while (index > 1) {
      int parent = index / 2;
      //if element is in "lower" level but should be higher swap
      if (cmp.compare(heap.get(index), heap.get(parent)) > 0) {
        T temp = heap.get(index);
        heap.set(index, heap.get(parent));
        heap.set(parent, temp);

        //move up to now where the element is (this cuts in half each time so O(log n) time
        index = parent;
      } else {
        break; //element is in correct place
      }
    }
  }

  @Override
  public void remove() throws EmptyException {
    if (empty()) {
      throw new EmptyException("Heap is empty, cannot remove.");
    }

    T root = heap.get(1);

    heap.set(1, heap.get(heap.size() - 1));
    heap.remove(heap.size() - 1);

    sinkDown(1);
  }

  private void sinkDown(int index) {

    int leftChild = 2 * index;
    int rightChild = 2 * index + 1;
    int largest = index;

    if (leftChild < heap.size() && cmp.compare(heap.get(leftChild), heap.get(largest)) > 0) {
      largest = leftChild;
    }

    if (rightChild < heap.size() && cmp.compare(heap.get(rightChild), heap.get(largest)) > 0) {
      largest = rightChild;
    }

    if (largest != index) {
      T temp = heap.get(index);
      heap.set(index, heap.get(largest));
      heap.set(largest, temp);

      sinkDown(largest);
    }
  }

  @Override
  public T best() throws EmptyException {
    if (empty()) {
      throw new EmptyException("Priority queue is empty");
    }
    return heap.get(1); //want to return the number that is at index 1
  }

  @Override
  public boolean empty() {
    return heap.size() == 1; //there is dummy variable at 0 so empty if size is 1
  }

  @Override
  public Iterator<T> iterator() {

    return new Iterator<T>() {

      private int currentIndex = 1;

      @Override
      public boolean hasNext() {
        return currentIndex < heap.size();
      }

      @Override
      public T next() {
        if (!hasNext()) {
          throw new NoSuchElementException("Priority queue is empty");
        }
        return heap.get(currentIndex++);
      }
    };
  }

  // Default comparator is the natural order of elements that are Comparable.
  private static class DefaultComparator<T extends Comparable<T>> implements Comparator<T> {
    public int compare(T t1, T t2) {
      return t1.compareTo(t2);
    }
  }



}
