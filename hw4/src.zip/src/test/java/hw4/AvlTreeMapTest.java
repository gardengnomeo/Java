package hw4;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * In addition to the tests in BinarySearchTreeMapTest (and in OrderedMapTest & MapTest),
 * we add tests specific to AVL Tree.
 */
@SuppressWarnings("All")
public class AvlTreeMapTest extends BinarySearchTreeMapTest {

  @Override
  protected Map<String, String> createMap() {
    return new AvlTreeMap<>();
  }

  @Test
  public void insertLeftRotation() {
    map.insert("1", "a");
    // System.out.println(avl.toString());
    // must print
    /*
        1:a
     */

    map.insert("2", "b");
    // System.out.println(avl.toString());
    // must print
    /*
        1:a,
        null 2:b
     */

    map.insert("3", "c"); // it must do a left rotation here!
    // System.out.println(avl.toString());
    // must print
    /*
        2:b,
        1:a 3:c
     */

    String[] expected = new String[]{
        "2:b",
        "1:a 3:c"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting insert causes right rotation if needed")
  public void testInsertRightRotation() {
    map.insert("3", "c");
    map.insert("2", "b");
    map.insert("1", "a");

    String[] expected = new String[]{
            "2:b",
            "1:a 3:c"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting insert causes right-left rotation if needed")
  public void testInsertRightLeftRotation() {
    map.insert("1", "a");
    map.insert("3", "c");
    map.insert("2", "b");

    String[] expected = new String[]{
            "2:b",
            "1:a 3:c"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting insert causes left-right rotation if needed")
  public void testInsertLeftRightRotation() {
    map.insert("3", "c");
    map.insert("1", "a");
    map.insert("2", "b");

    String[] expected = new String[]{
            "2:b",
            "1:a 3:c"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting insert and has work")
  public void testInsertAndHasWork() { //nevermind ralized I do not need this test as it is in MapTest but will keep
    map.insert("1", "a");

    String[] expected = new String[]{
            "1:a"
    };

    assertTrue(map.has("1"));
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting remove causes left rotation if needed")
  public void testRemoveLeftRotation() {
    map.insert("2", "b");
    map.insert("1", "a");
    map.insert("3", "c");
    map.insert("4", "d");
    map.remove("1");

    String[] expected = new String[]{
            "3:c",
            "2:b 4:d"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting remove causes right rotation if needed")
  public void testRemoveRightRotation() {
    map.insert("3", "c");
    map.insert("4", "d");
    map.insert("2", "b");
    map.insert("1", "a");
    map.remove("4");

    String[] expected = new String[]{
            "2:b",
            "1:a 3:c"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting remove causes right-left rotation if needed")
  public void testRemoveRightLeftRotation() {
    map.insert("2", "b");
    map.insert("1", "a");
    map.insert("4", "d");
    map.insert("3", "c");
    map.remove("1");

    String[] expected = new String[]{
            "3:c",
            "2:b 4:d"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting remove causes left-right rotation if needed")
  public void testRemoveLeftRightRotation() {
    map.insert("3", "c");
    map.insert("1", "a");
    map.insert("4", "d");
    map.insert("2", "b");
    map.remove("4");

    String[] expected = new String[]{
            "2:b",
            "1:a 3:c"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting removing the root node causes proper tree")
  public void testRemoveRootNode() {
    map.insert("3", "c");
    map.insert("1", "a");
    map.insert("4", "d");
    map.insert("2", "b");
    map.remove("3");

    String[] expected = new String[]{
            "2:b",
            "1:a 4:d"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting removing the root node causes proper tree")
  public void testRemoveRootNodeButNoLeftSmallest () {
    map.insert("3", "c");
    map.insert("4", "d");
    map.remove("3");

    String[] expected = new String[]{
            "4:d"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting removing the root node causes proper tree")
  public void testRemoveRootNodeLeftChildNoChildren() {
    map.insert("2", "b");
    map.insert("3", "c");
    map.insert("1", "a");
    map.remove("2");

    String[] expected = new String[]{
            "1:a",
            "null 3:c"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  //test size?
  //test

  @Test
  @DisplayName("Asserting put works") //oops did not need to do this one oh well double tested
  public void testPutWorks() {
    map.insert("2", "b");
    map.insert("3", "c");
    map.insert("1", "a");
    map.put("2","update");

    String[] expected = new String[]{
            "2:update",
            "1:a 3:c"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting size works")
  public void testSizeWorks() {
    map.insert("2", "b");
    map.insert("3", "c");
    map.insert("1", "a");

    assertEquals(3, map.size());
  }

  @Test
  @DisplayName("Asserting zie works after an update")
  public void testSizeWorksAfterUpdate() {
    map.insert("2", "b");
    map.insert("3", "c");
    map.insert("1", "a");
    map.put("2","update");

    assertEquals(3, map.size());
  }

  @Test
  @DisplayName("Asserting size works after a removal")
  public void testSizeWorksAfterRemove() {
    map.insert("2", "b");
    map.insert("3", "c");
    map.insert("1", "a");
    map.remove("2");

    assertEquals(2, map.size());
  }

  @Test
  @DisplayName("Asserting remove of root in single node tree works")
  public void testRemoveRootSingleNode() {
    map.insert("1", "a");
    map.remove("1");

    String[] expected = new String[]{
            ""
    };
    assertEquals((String.join("\n", expected)), map.toString());
  }

  @Test
  @DisplayName("Asserting remove of root in single node tree works and then adding another node")
  public void testRemoveRootSingleNodeThenAdd() {
    map.insert("1", "a");
    map.remove("1");
    map.insert("2", "b");

    String[] expected = new String[]{
            "2:b"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting remove throws exception for non existent key")
  public void testRemoveNonExistentKey() {
    map.insert("1", "a");
    map.insert("2", "b");
    map.insert("3", "c");

    try {
      map.remove("4");
      fail("IllegalArgumentException was not thrown for non existent key");
    } catch (IllegalArgumentException e) {
      //passed
    }

    String[] expected = new String[]{
            "2:b",
            "1:a 3:c"
    };

    assertEquals(String.join("\n", expected) + "\n", map.toString());
  }

  @Test
  @DisplayName("Asserting remove throws exception for null key")
  public void testRemoveNullKey() {
    map.insert("1", "a");
    map.insert("2", "b");
    map.insert("3", "c");

    try {
      map.remove(null);
      fail("IllegalArgumentException was not thrown for non existent key");
    } catch (IllegalArgumentException e) {
      //passed
    }

    String[] expected = new String[]{
            "2:b",
            "1:a 3:c"
    };

    assertEquals(String.join("\n", expected) + "\n", map.toString());
  }

  @Test
  @DisplayName("Asserting remove throws exception for different type key")
  public void testRemoveDifferentTypeKey() {
    map.insert("1", "a");
    map.insert("2", "b");
    map.insert("3", "c");

    try {
      map.remove("hello");
      fail("IllegalArgumentException was not thrown for different type key");
    } catch (IllegalArgumentException e) {
      //passed
    }

    String[] expected = new String[]{
            "2:b",
            "1:a 3:c"
    };

    assertEquals(String.join("\n", expected) + "\n", map.toString());
  }

  @Test
  @DisplayName("Multiple insertions and removals")
  public void testMultipleInsertionsAndRemovals() {
    map.insert("1", "a");
    map.insert("2", "b");
    map.insert("3", "c");
    map.insert("4", "d");
    map.remove("3");

    String[] expected = new String[] {
            "2:b",
            "1:a 4:d"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting behavior on inserting duplicate keys")
  public void testInsertDuplicateKey() {
    map.insert("1", "a");
    try {
      map.insert("1", "a");
      fail("IllegalArgumentException was not thrown for duplicate inserted key");
    } catch (IllegalArgumentException e) {
      //passed
    }

    String[] expected = new String[] {
            "1:a"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting insert throws exception for null key")
  public void testInsertNullKey() {
    map.insert("1", "a");
    map.insert("2", "b");
    map.insert("3", "c");

    try {
      map.insert(null, "c");
      fail("IllegalArgumentException was not thrown for non existent key");
    } catch (IllegalArgumentException e) {
      //passed
    }

    String[] expected = new String[]{
            "2:b",
            "1:a 3:c"
    };

    assertEquals(String.join("\n", expected) + "\n", map.toString());
  }

  @Test
  @DisplayName("Asserting put throws exception for null key")
  public void testPutNullKey() {
    map.insert("1", "a");
    map.insert("2", "b");
    map.insert("3", "c");

    try {
      map.put(null, "c");
      fail("IllegalArgumentException was not thrown for non existent key");
    } catch (IllegalArgumentException e) {
      //passed
    }

    String[] expected = new String[]{
            "2:b",
            "1:a 3:c"
    };

    assertEquals(String.join("\n", expected) + "\n", map.toString());
  }

  @Test
  @DisplayName("Asserting get throws exception for non-existent key")
  public void testGetNonExistentKey() {
    map.insert("1", "a");

    try {
      map.get("2");
      fail("IllegalArgumentException was not thrown for non-existent key");
    } catch (IllegalArgumentException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Asserting get throws exception for null key")
  public void testGetNullKey() {
    map.insert("1", "a");

    try {
      map.get(null);
      fail("IllegalArgumentException was not thrown for null key");
    } catch (IllegalArgumentException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Asserting parent with bf > 0 with child bf = 0 works")
  public void testEdgeCaseRotationWorks() {
    map.insert("2", "b");
    map.insert("4", "d");
    map.insert("1", "a");
    map.insert("3", "c");
    map.insert("5", "e");
    map.remove("1");

    String[] expected = new String[]{
            "4:d",
            "2:b 5:e",
            "null 3:c null null"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

}
