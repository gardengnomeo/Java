package hw4;

import exceptions.EmptyException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;

public abstract class PriorityQueueTest {

  private PriorityQueue<Integer> pq;

  @BeforeEach
  void setUp() {
    pq = this.createQueue();
  }

  abstract protected PriorityQueue<Integer> createQueue();

  @Test
  @DisplayName("PriorityQueue is empty after construction")
  void newQueueEmpty() {
    assertTrue(pq.empty());
  }

  @Test
  @DisplayName("Asserting best returns the element with highest priority")
  void testInsertBestElement() {
    pq.insert(10);
    pq.insert(20);
    pq.insert(5);

    assertEquals(20, pq.best());
  }

  @Test
  @DisplayName("Asserting removing the best element removes it from the queue")
  void testRemoveBestElement() {
    pq.insert(10);
    pq.insert(20);
    pq.insert(5);

    pq.remove();
    assertEquals(10, pq.best());
  }

  @Test
  @DisplayName("Asserting that removing the only element makes the queue empty")
  void testRemoveLastElementEmpty() {
    pq.insert(7);
    pq.remove();

    assertTrue(pq.empty());
  }

  @Test
  @DisplayName("Asserting removing from an empty queue throws EmptyException")
  void testRemoveFromEmptyQueue() {
    try {
      pq.remove();
      fail("Expected EmptyException but none was thrown");
    } catch (EmptyException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Asserting that calling best on an empty queue throws EmptyException")
  void testBestOnEmptyQueue() {
    try {
      pq.best();
      fail("Expected EmptyException but none was thrown");
    } catch (EmptyException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Asserting iterator traverses the heap in level-order")
  void testIterator() {
    pq.insert(40);
    pq.insert(30);
    pq.insert(20);
    pq.insert(10);
    pq.insert(25);

    Iterator<Integer> iterator = pq.iterator();

    assertTrue(iterator.hasNext());
    assertEquals(40, iterator.next()); // Root of heap
    assertEquals(30, iterator.next());
    assertEquals(20, iterator.next());
    assertEquals(10, iterator.next());
    assertEquals(25, iterator.next());

    assertFalse(iterator.hasNext());
  }

  @Test
  @DisplayName("Asserting inserting a single element works")
  void testInsertSingle() {
    pq.insert(30);
    assertEquals(30, pq.best());
  }

  @Test
  @DisplayName("Asserting get throws exception for null key")
  public void testInsertNullKey() {

    try {
      pq.insert(null);
      fail("IllegalArgumentException was not thrown for null key");
    } catch (IllegalArgumentException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Asserting iterator works for an empty queue")
  void testIteratorEmptyQueue() {
    Iterator<Integer> iterator = pq.iterator();
    assertFalse(iterator.hasNext());
  }

  @Test
  @DisplayName("Asserting iterator works for one element")
  void testIteratorOneElement() {
    pq.insert(10);
    Iterator<Integer> iterator = pq.iterator();
    assertTrue(iterator.hasNext());
    assertEquals(10, iterator.next());
    assertFalse(iterator.hasNext());
  }

}