package hw4;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;

/**
 * In addition to the tests in BinarySearchTreeMapTest (and in OrderedMapTest & MapTest),
 * we add tests specific to Treap.
 */
@SuppressWarnings("All")
public class TreapMapTest extends BinarySearchTreeMapTest {

  @Override
  protected Map<String, String> createMap() {
    return new TreapMap<>(13);
  }

  @Test
  @DisplayName("Asserting that insert works")
  void testInsertAndGet() {
    map.insert("1", "a");
    map.insert("2", "b");

    assertEquals("a", map.get("1"));
    assertEquals("b", map.get("2"));
  }

  @Test
  @DisplayName("Asserting rotate right works twice if needed")
  void testRotateRight() {
    map.insert("4", "d");
    map.insert("3", "c");
    map.insert("2", "b");
    map.insert("1", "a");

    String[] expected = new String[]{
            "4:d:-1160486312",
            "1:a:88367997 null",
            "null 3:c:1412442200 null null",
            "null null 2:b:1909600750 null null null null null"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting left right works twice if needed")
  void testRotateLeft() {
    map.insert("1", "a");
    map.insert("2", "b");
    map.insert("3", "c");
    map.insert("4", "d");

    String[] expected = new String[]{
            "1:a:-1160486312",
            "null 4:d:88367997",
            "null null 2:b:1412442200 null",
            "null null null null null 3:c:1909600750 null null"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Asserting Treap is empty after construction")
  void testTreapIsEmptyAfterConstruction() {
    assertEquals(0, map.size());
  }

  @Test
  @DisplayName("assert Treap insert throws exception for duplicate key")
  void testInsertThrowsExceptionDuplicateKey() {
    map.insert("1", "a");

    try {
      map.insert("1", "b");
      fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Assert Treap insert throws exception for null key")
  void testInsertThrowsExceptionNullKey() {
    map.insert("1", "a");

    try {
      map.insert(null, "b");
      fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Assert treap remove throws exception when key not found")
  void testRemoveThrowsException() {
    map.insert("1", "a");

    try {
      map.remove("2");
      fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Assert treap remove throws exception when Null key")
  void testRemoveThrowsExceptionForNull() {
    map.insert("1", "a");

    try {
      map.remove(null);
      fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Assert treap get throws exception when key not found")
  void testGetThrowsException() {
    map.insert("1", "1");

    try {
      map.get("2");
      fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Assert Treap removing root and doing rotations")
  void testMultipleRotations() {
    map.insert("4", "d");
    map.insert("3", "c");
    map.insert("2", "b");
    map.insert("1", "a");
    map.remove("4");

    String[] expected = new String[]{
            "1:a:88367997",
            "null 3:c:1412442200",
            "null null 2:b:1909600750 null"
    };
    assertEquals((String.join("\n", expected) + "\n"), map.toString());
  }

  @Test
  @DisplayName("Assert Treap put works")
  void testPutWorks() {
    map.insert("1", "a");
    map.put("1", "b");
    assertEquals("b", map.get("1"));
  }

  @Test
  @DisplayName("Assert treap put throws exception when key not found")
  void testPutThrowsException() {
    map.insert("1", "a");

    try {
      map.put("2", "b");
      fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      //passed
    }
  }

  @Test
  @DisplayName("Treap iterator works")
  void testIteratorWorks() {
    map.insert("1", "a");
    map.insert("2", "b");

    Iterator<String> iterator = map.iterator();
    assertTrue(iterator.hasNext());
    assertEquals("1", iterator.next());
    assertEquals("2", iterator.next());
  }






  // TODO Add tests
  //  (think about how you might write tests while randomness is involved in TreapMap implementation!)



}