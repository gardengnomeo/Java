package hw2;

public class SparseIndexedListTest extends IndexedListTest {

  @Override
  public IndexedList<Integer> createArray() {
    return new SparseIndexedList<>(LENGTH, INITIAL);
  }

  public IndexedList<Integer> createBetterArray(int length, Integer initialValue) {
    return new SparseIndexedList<>(length, initialValue);
  }

}