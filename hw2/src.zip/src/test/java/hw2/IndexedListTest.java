package hw2;

import exceptions.IndexException;
import exceptions.LengthException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit Tests for any class implementing the IndexedList interface.
 */
public abstract class IndexedListTest {
  protected static final int LENGTH = 10;
  protected static final int INITIAL = 7;
  private IndexedList<Integer> indexedList;

  public abstract IndexedList<Integer> createArray();
  public abstract IndexedList<Integer> createBetterArray(int length, Integer initial);

  @BeforeEach
  public void setup() {
    indexedList = createArray();
  }

  @Test
  @DisplayName("get() returns the default value after IndexedList is instantiated.")
  void testGetAfterConstruction() {
    for (int index = 0; index < indexedList.length(); index++) {
      assertEquals(INITIAL, indexedList.get(index));
    }
  }

  @Test
  @DisplayName("get() throws exception if index is below the valid range.")
  void testGetWithIndexBelowRangeThrowsException() {
    try {
      indexedList.get(-1);
      fail("IndexException was not thrown for index < 0");
    } catch (IndexException ex) {
      return;
    }
  }

  @Test
  @DisplayName("constructor throws exception if size is < 0.")
  void testConstructorThrowsExceptionForNegativeSize() {
    try {
      indexedList = createBetterArray(-LENGTH, INITIAL);
      fail("LengthException was not thrown where it was expected!");
    } catch (LengthException ex) {
      return;
    }
  }

  @Test
  @DisplayName("constructor throws exception if size is 0.")
  void testConstructorThrowsExceptionForZeroSize() {
    try {
      indexedList = createBetterArray(0, INITIAL);
      fail("LengthException was not thrown where it was expected!");
    } catch (LengthException ex) {
      return;
    }
  }

  @Test
  @DisplayName("get() returns the default value after IndexedList is instantiated using null as default value.")
  void testGetAfterConstructionWithNullAsDefaultValue() {
    indexedList = createBetterArray(LENGTH, null);
    for (int index = 0; index < indexedList.length(); index++) {
        assertNull(indexedList.get(index));
    }
  }

  @Test
  @DisplayName("get() throws exception if index is above the valid range.")
  void testGetWithIndexAboveRangeThrowsException() {
    try {
      indexedList.get(LENGTH + 1);
      fail("IndexException was not thrown for index > length");
    } catch (IndexException ex) {
      return;
    }
  }

  @Test
  @DisplayName("put() throws exception if index is below the valid range.")
  void testPutWithIndexBelowRangeThrowsException() {
    try {
      indexedList.put(-1, 10);
      fail("IndexException was not thrown for index < 0");
    } catch (IndexException ex) {
      return;
    }
  }

  @Test
  @DisplayName("put() throws exception if index is above the valid range.")
  void testPutWithIndexAboveRangeThrowsException() {
    try {
      indexedList.put(LENGTH, 10);
      fail("IndexException was not thrown for index > length");
    } catch (IndexException ex) {
      return;
    }
  }

  @Test
  @DisplayName("put() changes the default value after IndexedList is instantiated.")
  void testPutChangesValueAfterConstruction() {
    indexedList.put(2, 8);
    assertEquals(8, indexedList.get(2));
  }

  @Test
  @DisplayName("put() doesnt change the default value after default to one it already is.")
  void testPutDoesNotChangeValueAfterToDefault() {
    indexedList.put(2, INITIAL);
    assertEquals(INITIAL, indexedList.get(2));
  }

  @Test
  @DisplayName("put() does not change the value if it is already there.")
  void testPutKeepsValueAfterChangeToSame() {
    indexedList.put(1, 8);
    assertEquals(8, indexedList.get(1));
    indexedList.put(1, 8);
    assertEquals(8, indexedList.get(1));
  }

  @Test
  @DisplayName("put() overwrites the existing value at given index to provided value.")
  void testPutUpdatesValueAtGivenIndex() {
    indexedList.put(1, 8);
    assertEquals(8, indexedList.get(1));
    indexedList.put(1, -5);
    assertEquals(-5, indexedList.get(1));
  }

  @Test
  @DisplayName("put() updates multiple values at different indexes.")
  void testPutUpdatesValueAtManyIndex() {
    indexedList.put(1, 8);
    assertEquals(8, indexedList.get(1));
    indexedList.put(2, -5);
    assertEquals(-5, indexedList.get(2));
    indexedList.put(3, 2);
    assertEquals(2, indexedList.get(3));
  }

  @Test
  @DisplayName("put() only changes the value at given index to provided value.")
  void testPutOnlyUpdatesValueAtGivenIndex() {
    indexedList.put(1, 8);
    assertEquals(INITIAL, indexedList.get(0));
    assertEquals(8, indexedList.get(1));
    assertEquals(INITIAL, indexedList.get(2));
  }

  @Test
  @DisplayName("put() changes back to the default value given the default value.")
  void testPutUpdatesBackDefaultValueAtGivenIndex() {
    indexedList.put(1, 8);
    assertEquals(8, indexedList.get(1));
    indexedList.put(1, INITIAL);
    assertEquals(INITIAL, indexedList.get(1));
  }

  @Test
  @DisplayName("put() updates the value given the first index.")
  void testPutUpdatesValueGivenFirstIndex() {
    indexedList.put(0, 8);
    assertEquals(8, indexedList.get(0));
  }

  @Test
  @DisplayName("put() updates the value given the last index.")
  void testPutUpdatesValueGivenLastIndex() {
    indexedList.put(LENGTH - 1, 8);
    assertEquals(8, indexedList.get(LENGTH - 1));
  }

  @Test
  @DisplayName("put() updates the value given null as value.")
  void testPutUpdatesValueGivenNull() {
    indexedList.put(1, null);
      assertNull(indexedList.get(1));
  }

  @Test
  @DisplayName("put() overwrites the existing value at given index to null value.")
  void testPutUpdatesValueGivenNullValue() {
    indexedList.put(1, null);
    assertNull(indexedList.get(1));
    indexedList.put(1, -5);
    assertEquals(-5, indexedList.get(1));
  }

  @Test
  @DisplayName("length() returns the correct size after IndexedList is instantiated.")
  void testLengthAfterConstruction() {
    assertEquals(LENGTH, indexedList.length());
  }

  @Test
  @DisplayName("test iterator after IndexedList is instantiated.")
  void testEnhancedLoopAfterConstruction() {
    int counter = 0;
    for (int element : indexedList) {
      assertEquals(INITIAL, element);
      counter++;
    }
    assertEquals(LENGTH, counter);
  }

  @Test
  @DisplayName("test iterator after IndexedList is changed.")
  void testEnhancedLoopAfterListChanged() {
    indexedList.put(0, 8);
    indexedList.put(LENGTH - 1, 10);

    int counter = 0;
    for (int element : indexedList) {
      if (counter == 0) {
        assertEquals(8, element);
      } else if (counter == (LENGTH -1) ) {
        assertEquals(10, element);
      } else {
        assertEquals(INITIAL, element);
      }
      counter++;
    }
    assertEquals(LENGTH, counter);
  }

  @Test
  @DisplayName("test iterator after IndexedList is instantiated.")
  void testEnhancedLoopAfterConstructionLengthOne() {
    indexedList = createBetterArray(1, INITIAL);
    int counter = 0;
    for (int element : indexedList) {
      assertEquals(INITIAL, element);
      counter++;
    }
    assertEquals(1, counter);
  }

  @Test
  @DisplayName("test iterator after IndexedList is instantiated.")
  void testEnhancedLoopAfterConstructionWithNullIndex() {
    indexedList = createBetterArray(LENGTH, null);
    int counter = 0;
    for (Integer element : indexedList) {
      assertNull(element);
      counter++;
    }
    assertEquals(LENGTH, counter);
  }


}
