# Discussion
I think that ArrayIndexedList would be the best implementation as
it will allow for proper binary search. It is the only one that
of the three that is able to have a binary search that would
work to its desired efficiency. LinkedIndexList and SparseIndexedList are both a
form of linked lists and so you would have to traverse the list
to get a node, in other words you can not just access
the middle node easily. Additionally, it does not make sense to use
SparseIndexedList in this case as it should be used where there is a default
value that should be stored but in this case there most likely would not
be a default value.

