package hw2;

import exceptions.IndexException;
import exceptions.LengthException;
import java.util.Iterator;
import java.util.NoSuchElementException;


/**
 * An implementation of an IndexedList designed for cases where
 * only a few positions have distinct values from the initial value.
 *
 * @param <T> Element type.
 */
public class SparseIndexedList<T> implements IndexedList<T> {

  private final int size;
  private final T defaultValue;
  private Node<T> head;

  /**
   * Constructs a new SparseIndexedList of length size
   * with default value of defaultValue.
   *
   * @param size         Length of list, expected: size > 0.
   * @param defaultValue Default value to store in each slot.
   * @throws LengthException if size <= 0.
   */
  public SparseIndexedList(int size, T defaultValue) throws LengthException {

    if (size <= 0) {
      throw new LengthException("Size must be greater than 0");
    }

    this.size = size;
    this.defaultValue = defaultValue;

  }


  @Override
  public int length() {
    return size; // the length is just the size
  }

  @Override
  public T get(int index) throws IndexException {

    // check index
    if (index < 0 || index >= size) {
      throw new IndexException("Index out of bounds");
    }

    Node<T> current = head;

    //check if any of the non default nodes are at the index break if passes index
    while (current != null) {
      if (current.position == index) {
        return current.data;
      } else if (current.position > index) {
        break;
      }
      current = current.next;
    }
    return defaultValue;
  }

  @Override
  public void put(int index, T value) throws IndexException {
    if (index < 0 || index >= size) {
      throw new IndexException("Index out of bounds");
    }

    if (value == defaultValue) {
      defaultNode(index);
    } else {
      nonDefaultNode(index, value);
    }
  }


  /*
  Helper function for put() to break code up removes the node if the default value is the value
  for the new node
   */
  private void defaultNode(int index) {
    Node<T> current = head;
    Node<T> previous = null;

    //call function that does this stuff
    while (current != null) {
      if (current.position == index) {
        if (previous == null) {
          head = current.next;
          return;
        } else {
          previous.next = current.next;
        }
      } else if (current.position > index) {
        return;
      }
      previous = current;
      current = current.next;
    }
  }

  /*
  Helper function for put() that adds a node if the value is non default node
   */
  private void nonDefaultNode(int index, T value) {

    Node<T> current = head;
    Node<T> previous = null;

    while (current != null) { //iterate through
      if (current.position == index) { //if index is already a node
        current.data = value;
        return;

      } else if (current.position > index) { //if not and need to insert a node
        insertNode(previous, current, index, value);
        return;
      }
      previous = current;
      current = current.next;
    }

    //if the node needs to be inserted all the way in the last element
    insertNode(previous, null, index, value);
  }

  private void insertNode(Node<T> previous, Node<T> current, int index, T value) {

    Node<T> node = new Node<>(value, index);
    if (previous == null) { //node at head
      node.next = head;
      head = node;
    } else { //place node between others elsewhere
      node.next = current;
      previous.next = node;
    }

  }




  // node stores its position as well to make knowing where the non default data is
  private static class Node<E> {
    E data;
    int position;
    Node<E> next;

    Node(E data, int position) {
      this.data = data;
      this.position = position;
    }
  }

  @Override
  public Iterator<T> iterator() {
    return new SparseIndexedListIterator();
  }

  private class SparseIndexedListIterator implements Iterator<T> {

    private Node<T> current;
    private int currentPosition;

    SparseIndexedListIterator() {
      current = head;
      currentPosition = 0;
    }

    @Override
    public boolean hasNext() {
      return currentPosition < size;
    }

    @Override
    public T next() throws NoSuchElementException {
      if (!hasNext()) { // check if there is a next value
        throw new NoSuchElementException();
      }

      T data;

      //check if there is a node and which output to return
      if (current != null && current.position == currentPosition) {
        data = current.data;
        current = current.next;
      } else {
        data = defaultValue;
      }

      currentPosition++;
      return data;
    }
  }
}
