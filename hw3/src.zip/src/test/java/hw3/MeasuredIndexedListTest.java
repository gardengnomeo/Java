package hw3;

import exceptions.IndexException;
import hw3.sort.MeasuredIndexedList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class MeasuredIndexedListTest {

  private static final int LENGTH = 15;
  private static final int DEFAULT_VALUE = 3;

  private MeasuredIndexedList<Integer> measuredIndexedList;

  @BeforeEach
  void setup() {
    measuredIndexedList = new MeasuredIndexedList<>(LENGTH, DEFAULT_VALUE);
  }

  @Test
  @DisplayName("MeasuredIndexedList starts with zero reads")
  void zeroReadsStart() {
    assertEquals(0, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("MeasuredIndexedList starts with zero writes")
  void zeroWritesStart() {
    assertEquals(0, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("Ensure the constructor works and returns the right length")
  void testLengthReturnsValue() {
    assertEquals(LENGTH, measuredIndexedList.length());
  }

  @Test
  @DisplayName("Ensure the constructor works and returns the right value for get")
  void testGetReturnsValue() {
    assertEquals(DEFAULT_VALUE, measuredIndexedList.get(0));
  }

  @Test
  @DisplayName("Ensure that exception thrown for index < 0")
  void testGetReturnsIndexExceptionLessThanZero() {
    try {
      measuredIndexedList.get(-1);
      fail("IndexException was not thrown for index < 0");
    } catch (IndexException ex) {
      return;
    }
  }

  @Test
  @DisplayName("Ensure that exception thrown for index > length")
  void testGetReturnsIndexException() {
    try {
      measuredIndexedList.get(LENGTH);
      fail("IndexException was not thrown for index > length");
    } catch (IndexException ex) {
      return;
    }
  }

  @Test
  @DisplayName("Ensure accessCount gets updated after get")
  void testAccessCountUpdatedAfterGet() {
    measuredIndexedList.get(0);
    assertEquals(1, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure accessCount does not gets updated after bad get")
  void testAccessCountNotUpdatedAfterBadGet() {

    try {
      measuredIndexedList.get(LENGTH);
      fail("IndexException was not thrown for index > length");
    } catch (IndexException ex) {
      assertEquals(0, measuredIndexedList.accesses());
    }
  }

  @Test
  @DisplayName("Ensure mutationCount gets updated after put")
  void testAccessCountUpdatedAfterPut() {
    measuredIndexedList.put(0,1);
    assertEquals(1, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("put() throws exception if index is below the valid range.")
  void testPutWithIndexBelowRangeThrowsException() {
    try {
      measuredIndexedList.put(-1, 10);
      fail("IndexException was not thrown for index < 0");
    } catch (IndexException ex) {
      return;
    }
  }

  @Test
  @DisplayName("put() throws exception if index is above the valid range.")
  void testPutWithIndexAboveRangeThrowsException() {
    try {
      measuredIndexedList.put(LENGTH, 10);
      fail("IndexException was not thrown for index > length");
    } catch (IndexException ex) {
      return;
    }
  }

  @Test
  @DisplayName("Ensure Both Counts gets updated after get and put")
  void testBothCountUpdatedAfterGetAndPut() {
    measuredIndexedList.put(0,1);
    measuredIndexedList.get(0);
    assertEquals(1, measuredIndexedList.mutations());
    assertEquals(1, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure accessCount gets updated after multiple gets")
  void testAccessCountUpdatedAfterMultipleGet() {
    measuredIndexedList.get(0);
    measuredIndexedList.get(1);
    assertEquals(2, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure mutationCount does not gets updated after bad put")
  void testAccessCountNotUpdatedAfterBadPut() {
    try {
      measuredIndexedList.put(-1, 10);
      fail("IndexException was not thrown for index < 0");
    } catch (IndexException ex) {
      assertEquals(0, measuredIndexedList.accesses());
    }
  }

  @Test
  @DisplayName("Ensure mutationCount updated with good put after bad put")
  void testAccessCountUpdatedAfterBadPut() {
    try {
      measuredIndexedList.put(-1, 10);
      fail("IndexException was not thrown for index < 0");
    } catch (IndexException ex) {
      assertEquals(0, measuredIndexedList.mutations());
    }
    measuredIndexedList.put(0, 10);
    assertEquals(1, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("Ensure mutationCount updated with good get after bad get")
  void testAccessCountUpdatedAfterBadGet() {
    try {
      measuredIndexedList.get(-1);
      fail("IndexException was not thrown for index < 0");
    } catch (IndexException ex) {
      assertEquals(0, measuredIndexedList.accesses());
    }
    measuredIndexedList.get(0);
    assertEquals(1, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure reset works if both counts were already 0")
  void testResetWorksIfBothCountsWereAlreadyZero() {
    measuredIndexedList.reset();
    assertEquals(0, measuredIndexedList.accesses());
    assertEquals(0, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("Ensure accessCount gets updated after reset")
  void testAccessCountUpdatedAfterReset() {
    measuredIndexedList.get(0);
    measuredIndexedList.reset();
    assertEquals(0, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure mutationCount gets updated after reset")
  void testMutationCountUpdatedAfterReset() {
    measuredIndexedList.put(0, 10);
    measuredIndexedList.reset();
    assertEquals(0, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("Ensure count works")
  void testCountWorks() {
    assertEquals(LENGTH, measuredIndexedList.count(DEFAULT_VALUE));
  }

  @Test
  @DisplayName("Ensure count works with no value found")
  void testCountWorksNoValueFound() {
    assertEquals(0, measuredIndexedList.count(4));
  }

  @Test
  @DisplayName("Ensure count works with changed inputs")
  void testCountWorksChangedInputs() {
    measuredIndexedList.put(0, 10);
    assertEquals(LENGTH-1, measuredIndexedList.count(DEFAULT_VALUE));
  }

  @Test
  @DisplayName("Ensure count works with changed inputs")
  void testAccessCountUpdatedAfterCount() {
    measuredIndexedList.count(DEFAULT_VALUE);
    assertEquals(LENGTH, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure count works with non standard count value")
  void testAccessCountUpdatedAfterCountWithNonStandardValue() {
    measuredIndexedList.count(4);
    assertEquals(LENGTH, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure length does not update accessCount")
  void testLengthDoesNotUpdateAccessCount() {
    measuredIndexedList.length();
    assertEquals(0, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure length does not update mutationCount")
  void testLengthDoesNotUpdateMutationCount() {
    measuredIndexedList.length();
    assertEquals(0, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("Ensure count does not update mutationCount")
  void testCountDoesNotUpdateMutationCount() {
    measuredIndexedList.count(DEFAULT_VALUE);
    assertEquals(0, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("Ensure reset works after count")
  void testResetWorksAfterCount() {
    measuredIndexedList.count(DEFAULT_VALUE);
    measuredIndexedList.reset();
    assertEquals(0, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure accessCount updated after multiple count")
  void testAccessCountUpdatedAfterMultipleCount() {
    measuredIndexedList.count(DEFAULT_VALUE);
    measuredIndexedList.count(4);
    assertEquals(2*LENGTH, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure accessCount not updated after put")
  void testAccessCountNotUpdatedAfterPut() {
    measuredIndexedList.put(2,10);
    assertEquals(0, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure mutationCount not updated after get")
  void testMutationCountNotUpdatedAfterGet() {
    measuredIndexedList.get(2);
    assertEquals(0, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("Ensure mutationCount updated after multiple put")
  void testAccessCountNotUpdatedAfterMultiplePut() {
    measuredIndexedList.put(2,10);
    measuredIndexedList.put(3,10);
    assertEquals(2, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("Ensure mutationCount updated after same put")
  void testAccessCountNotUpdatedAfterSamePut() {
    measuredIndexedList.put(2,10);
    measuredIndexedList.put(2,2);
    assertEquals(2, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("Ensure length not updated after multiple put")
  void testLengthNotUpdatedAfterMultiplePut() {
    measuredIndexedList.put(0,10);
    measuredIndexedList.put(2,2);
    assertEquals(LENGTH, measuredIndexedList.length());
  }

  @Test
  @DisplayName("Ensure both Count gets updated after updates and reset")
  void testBothCountUpdatedAfterReset() {
    measuredIndexedList.get(0);
    measuredIndexedList.put(2,2);
    measuredIndexedList.reset();
    assertEquals(0, measuredIndexedList.accesses());
    assertEquals(0, measuredIndexedList.mutations());
  }

  @Test
  @DisplayName("Ensure iterator works correctly")
  void testIteratorWorksCorrectly() {
    int count = 0;
    for (Integer value : measuredIndexedList) {
      assertEquals(DEFAULT_VALUE, value);
      count++;
    }
    assertEquals(LENGTH, count);
  }

  @Test
  @DisplayName("Ensure accessCount gets updated for last index")
  void testAccessCountUpdatedForLastIndex() {
    measuredIndexedList.get(LENGTH - 1);
    assertEquals(1, measuredIndexedList.accesses());
  }

  @Test
  @DisplayName("Ensure mutationCount gets updated after for last index")
  void testMutationCountUpdatedForLastIndex() {
    measuredIndexedList.put(LENGTH - 1,2);
    assertEquals(1, measuredIndexedList.mutations());
  }


}
