package hw3.search;

import java.util.Iterator;

/**
 * Set implemented using a doubly linked list and move-to-front heuristic.
 *
 * @param <T> Element type.
 */
public class MoveToFrontLinkedSet<T> extends LinkedSet<T> {

  @Override
  protected Node<T> find(T t) {

    Node<T> node = super.find(t);

    if (node != null) {
      moveToFront(node);
    }
    return node;
  }




  private void moveToFront(Node<T> node) {

    //check if node is the head (no need to move)
    if (node == head) {
      return;
    }

    //remove it from the list
    node.prev.next = node.next;
    if (node.next != null) {
      node.next.prev = node.prev;
    }

    //check if it was the tail
    if (node == tail) {
      tail = node.prev;
    }

    //insert the node at front
    node.next = head;
    if (head != null) {
      head.prev = node;
    }
    node.prev = null;
    head = node;
  }

  private static void printOut(MoveToFrontLinkedSet<String> linkedSet) {
    Iterator<String> iterator = linkedSet.iterator();
    while (iterator.hasNext()) {
      System.out.print(iterator.next() + " ");
    }
    System.out.println();
  }

  /**
   * Main to test code and see how it works.
   *
   * @param args input to main
   */
  public static void main(String[] args) {

    MoveToFrontLinkedSet<String> linkedSet = new MoveToFrontLinkedSet<>();

    for (int i = 0; i < 5; i++) {
      linkedSet.insert(String.valueOf(i));
    }

    printOut(linkedSet);

    linkedSet.remove("1");
    printOut(linkedSet);

    linkedSet.has("2");
    printOut(linkedSet);

    linkedSet.insert("1");
    printOut(linkedSet);

  }
}
