package hw3.search;

import java.util.Iterator;

/**
 * Set implemented using plain Java arrays and transpose-sequential-search heuristic.
 *
 * @param <T> Element type.
 */
public class TransposeArraySet<T> extends ArraySet<T> {


  @Override
  public int find(T t) {

    int index = super.find(t);
    //switch the two values
    if (index > 0) {
      T temp = data[index];
      data[index] = data[index - 1];
      data[index - 1] = temp;
      index = index - 1;
    }
    return index;
  }

  private static void printOut(TransposeArraySet<String> linkedSet) {
    Iterator<String> iterator = linkedSet.iterator();
    while (iterator.hasNext()) {
      System.out.print(iterator.next() + " ");
    }
    System.out.println();
  }

  /**
   * Main to test code and see how it works.
   *
   * @param args input to main
   */
  public static void main(String[] args) {

    TransposeArraySet<String> linkedSet = new TransposeArraySet<>();

    for (int i = 0; i < 7; i++) {
      linkedSet.insert(String.valueOf(i));
    }

    printOut(linkedSet);

    linkedSet.remove("3");
    printOut(linkedSet);

    linkedSet.has("2");
    printOut(linkedSet);

    linkedSet.has("2");
    printOut(linkedSet);

    linkedSet.insert("3");
    printOut(linkedSet);


  }
}
