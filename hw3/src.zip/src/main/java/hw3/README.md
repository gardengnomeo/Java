# Discussion

## PART I: MeasuredIndexedList Iterator

I think that from a design perspective iterating over a MeasuredIndexedList
should affect the accesses count but not the mutation count. This is because
the iterator will go through the whole list and access each element when it
returns it. It should not update mutation count though as it is not changing
any of the values only accessing them.

If you wanted to include the has and hasNext methods from ArrayIndexedListIterator
you would not be abel to inherit them as they are in a private inner class, and so they
can not be accessed to be overridden. If you wanted to implement them you would have to
implement a new iterator interface to get those functionalities.

## PART II: Profiling Sorting Algorithms

By running the SortingAlgorithmDriver I found the values for the different sorts. I ran it
a few times, so I could get an average sense of how long they take and how many steps. I noticed
that gnome sort took almost double the amount of time than the others for descending data and that
it also took 1.5-3 times more accesses than the others. I also noticed that it was doing worse than it was for
random data though this is most likely supposed to be expected as a list that is in reverse order
needs to be fully switched which can take a while. I then looked at the code for GnomeSort, but it
looked like the code was sound and would work the way it was expected. I then decided to look at the
data to ensure that ascending was actually ascending and that I was not just assuming. Then I looked at
descending.data and noticed that it was partially descending. However, I noticed that every ten values it
would go to a 3-digit number instead of 4. This means that the descending data was not actually descending
and is the discrepancy. I tried to find a set of data from 9999 to 1 online to copy and paste to compare
the times, but I was unable to find a data set like that. This most likely lead to the sorts actually working
faster than intended as the worst case is the descending order and as it was not descending it was not actually
the worst case. I then looked through the sorting algorithms to see if the code made sense, and it did, so I don't
think there is an error in any of the sorting algorithms, and they also do sort the data so I think the only error
was the descending data.

## PART III: Analysis of Selection Sort

Comparisons:
1) None 
2) None 
3) Compares each time plus one at the end after so (N-1)+1 = N
4) None
5) Compares each time plus one at end but only from j to length where j is i+1 so it will be
N-i-1+1 times so N-i times, i will increment from (n-1)+(n-2)+(n-3)+...+1 this is a sum that
be written as ((n-1)n)/2 this is then multiplied by (n-1) for the outer loop so: (n^2-n)/2
6) this is one comparison which happens the times of the loop which is: (n^2-n)/2
No more comparisons and so the total is : (n^2-n)/2 + (n^2-n)/2 + n = n^2 which goes to O(n^2)


Assignments:
1) None
2) None
3) 1 for i=0, and then N-1 for i++ so: N
4) 1 for max = i in for loop which is N-1 times so: N-1
5) 1 for j = i+1, and j++ happens N-i-1 times as only from i+1 to length(N) using the logic from line 5 of 
6) None
7) This is the same as line 6 but for comparisons as there is only assignment so (n^2-n)/2
10-12) One assignment per line in the n-1 for loop so 3(n-1) = 3n-3
This goes to a total of N + N-1 + (n^2-n)/2 + (n^2-n)/2 + 3N-3 = N^2+N-1+4N-4 = N^2+4N-4 which goes to O(N^2)


## PART IV: Reflecting on Search Heuristics

For MoveToFrontLinkedSet the remove method calls find which brings the node that is to be removed
to the front but that does not make a difference as it then removes it updating the head to be the
next node which was already the first node. This is unnecessary but does not change the way the list
is. 

For TransposeArraySet the remove method calls find which then switches the remove element up one and then
the element gets removed. The removal swaps the last element with the one that should be removed and then
sets the element to be removed (at last index of an element) as null. This does not work with the heuristics
as the last element should be the one least used however if you use remove on an element close to the front
it will then put that element that is hardly used closer to the front. This will cause the has to not work
as efficiently as there will be elements that are not referenced frequently close to the front if some get
removed.


## PART V: Profiling Search Heuristics

In my experiment I will use the has method on one of the elements that is at the end of the two sets.
This will make the MoveToFront and TransposeSequence faster as they are only faster when an element is
accessed frequently. This was the case, and it was faster when accessing one of the elements multiple times
as that is what the heuristics do. If I had not seen any measurable differences Then I would probably say that
would need to access the element more or also provide a larger data set so that the non-heuristic versions need
to go though many more elements. I would also make it so that the element is accessed many times after it has been
moved fully to the front so that it has a difference from the ones accessed at the back.