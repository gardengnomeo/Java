package hw3.sort;


/**
 * The Insertion Sort algorithm, with minimizing swaps optimization.
 *
 * @param <T> Element type.
 */
public final class InsertionSort<T extends Comparable<T>>
    implements SortingAlgorithm<T> {

  @Override
  public void sort(IndexedList<T> indexedList) {

    for (int i = 1; i < indexedList.length(); i++) {
      T curr = indexedList.get(i);
      int j = i;

      while (j > 0 && indexedList.get(j - 1).compareTo(curr) > 0) {
        indexedList.put(j, indexedList.get(j - 1));
        j--;
      }
      indexedList.put(j, curr);
    }
  }


  @Override
  public String name() {
    return "Insertion Sort";
  }
}
