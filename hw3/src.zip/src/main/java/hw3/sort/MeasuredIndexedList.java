package hw3.sort;

import exceptions.IndexException;

/**
 * An ArrayIndexedList that is able to report the number of
 * accesses and mutations, as well as reset those statistics.
 *
 * @param <T> The type of the array.
 */
public class MeasuredIndexedList<T> extends ArrayIndexedList<T>
    implements Measured<T> {

  private int accessCount;
  private int mutationCount;

  /**
   * Constructor for a MeasuredIndexedList.
   *
   * @param size         The size of the array.
   * @param defaultValue The initial value to set every object to in the array.
   */
  public MeasuredIndexedList(int size, T defaultValue) {
    super(size, defaultValue);
  }

  @Override
  public int length() {
    return super.length();
  }

  @Override
  public T get(int index) throws IndexException {
    T returnValue = super.get(index);
    accessCount++;
    return returnValue;
  }

  @Override
  public void put(int index, T value) throws IndexException {
    super.put(index, value);
    mutationCount++;
  }

  @Override
  public void reset() {
    accessCount = 0;
    mutationCount = 0;
  }

  @Override
  public int accesses() {
    return accessCount;
  }

  @Override
  public int mutations() {
    return mutationCount;
  }

  @Override
  public int count(T value) {

    int count = 0;

    for (int i = 0; i < length(); i++) {
      //get already increments accessCount so no need to do here
      if (get(i).equals(value)) {
        count++;
      }
    }
    return count;
  }

}
